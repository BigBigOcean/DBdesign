<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"G:\phpStudy\PHPTutorial\WWW\tp5\public/../application/index\view\index\show.html";i:1545468905;}*/ ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
    <!--<![endif]-->

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>X酒店信息管理系统</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Facebook and Twitter integration -->
        <meta property="og:title" content="" />
        <meta property="og:image" content="" />
        <meta property="og:url" content="" />
        <meta property="og:site_name" content="" />
        <meta property="og:description" content="" />
        <meta name="twitter:title" content="" />
        <meta name="twitter:image" content="" />
        <meta name="twitter:url" content="" />
        <meta name="twitter:card" content="" />

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="favicon.ico">
        <!-- <link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,900,700,900italic' rel='stylesheet' type='text/css'> -->

        <!-- Stylesheets -->
        <!-- Dropdown Menu -->
        <link rel="stylesheet" href="static/css/superfish.css">
        <!-- Owl Slider -->
        <!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
        <!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
        <!-- Date Picker -->
        <link rel="stylesheet" href="static/css/bootstrap-datepicker.min.css">
        <!-- CS Select -->
        <link rel="stylesheet" href="static/css/cs-select.css">
        <link rel="stylesheet" href="static/css/cs-skin-border.css">

        <!-- Themify Icons -->
        <link rel="stylesheet" href="static/css/themify-icons.css">
        <!-- Flat Icon -->
        <link rel="stylesheet" href="static/css/flaticon.css">
        <!-- Icomoon -->
        <link rel="stylesheet" href="static/css/icomoon.css">
        <!-- Flexslider  -->
        <link rel="stylesheet" href="static/css/flexslider.css">

        <!-- Style -->
        <link rel="stylesheet" href="static/css/style.css">

        <!-- Modernizr JS -->
        <script src="static/js/modernizr-2.6.2.min.js"></script>
        <!-- FOR IE9 below -->
        <!--[if lt IE 9]>
    <script src="static/js/respond.min.js"></script>
    <![endif]-->

        <!--当前时间脚本-->
        <script type="text/javascript">
            Date.prototype.Format = function(fmt) { //author: meizz
                var o = {
                    "M+": this.getMonth() + 1, //月份
                    "d+": this.getDate(), //日
                    "h+": this.getHours(), //小时
                    "m+": this.getMinutes(), //分
                    "s+": this.getSeconds(), //秒
                    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
                    "S": this.getMilliseconds() //毫秒
                };
                if(/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
                for(var k in o)
                    if(new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                return fmt;
            }
            var currentTime = new Date().Format("yyyy-MM-dd");
        </script>

        <!--选择入住和离店时间-->
        <script src="static/js/laydate/laydate.js"></script>
        <script>
            var comeTime = leaveTime = currentTime;
            lay('#version').html('-v' + laydate.v);
            //执行一个laydate实例
            laydate.render({
                elem: '#comeTimeSelecotor' //指定元素
                    ,
                min: currentTime //最小选择时间
                    ,
                value: currentTime //初始值
                    ,
                calendar: true,
                done: function(value, date, endDate) {
                    //console.log(value); //得到日期生成的值，如：2017-08-18
                    //console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                    //console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                    comeTime = value;
                    console.log("选择入住时间：" + comeTime);
                }
            });

            laydate.render({
                elem: '#leaveTimeSelector' //指定元素
                    ,
                calendar: true,
                min: comeTime //初始值
                    ,
                done: function(value, date, endDate) {
                    //console.log(value); //得到日期生成的值，如：2017-08-18
                    //console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                    //console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                    leaveTime = value;
                    console.log("选择离店时间：" + leaveTime);
                }
            });
        </script>

        <!--ajax交互-->
        <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
        <script>
            function ajaxPost() {

                var roomType = $("#room-type").val();
                var startTime = $("#comeTimeSelecotor").val();
                var endTime = $("#leaveTimeSelector").val();
                var guestNumber = $("#guest-number").val();

                $.ajax({
                    type: "post",
                    url: "<?php echo url('Search/index/dosearch'); ?>",
                    data: {
                        roomType: roomType,
                        startTime: startTime,
                        endTime: endTime,
                        guestNumber: guestNumber
                    },
                    success: function(data) {

                        var res = JSON.stringify(data);
                        //alert(JSON.stringify(data));
                        //console.log(data);
                        var path = "<?php echo url('/search/index?roomType=" + roomType + "&startTime=" + startTime +
                            "&endTime=" + endTime + "&guestNumber=" + guestNumber + "&result=" + res +
                            "&other=null" + "'); ?>";
                        document.location = path;
                        //console.log(data);
                    }
                });

            }
        </script>

    </head>

    <body>
        <!--右上角菜单栏-->
        <div id="fh5co-header">
            <header id="fh5co-header-section">
                <div class="container">
                    <div class="nav-header">
                        <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
                        <h1 id="fh5co-logo"><a href="index.html">X酒店信息管理系统</a></h1>
                        <nav id="fh5co-menu-wrap" role="navigation">
                            <ul class="sf-menu" id="fh5co-primary-menu">
                                <li>
                                    <a class="active" href="index.html">主页</a>
                                </li>
                                <li>
                                    <a href="hotel.html" class="fh5co-sub-ddown">房型</a>
                                    <ul class="fh5co-sub-menu">
                                        <li>
                                            <a href="#">标准大床房</a>
                                        </li>
                                        <li>
                                            <a href="#">标准双床房</a>
                                        </li>
                                        <li>
                                            <a href="#">豪华大床房</a>
                                        </li>
                                        <li>
                                            <a href="#">豪华双床房</a>
                                        </li>
                                        <li>
                                            <a href="#">家庭亲子套房</a>
                                        </li>
                                        <li>
                                            <a href="#">复式套房</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" onclick="gotoSer()" >我的</a>
                                </li>
                                <li>
                                    <a href="blog.html">图册</a>
                                </li>
                                <li>
                                    <a href="contact.html">关于我们</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </header>

        </div>

        <div id="fh5co-wrapper">
            <div id="fh5co-page">
                <div id="fh5co-header">
                    <header id="fh5co-header-section">
                        <div class="container">
                            <div class="nav-header">
                                <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
                                <h1 id="fh5co-logo"><a href="index.html">X酒店信息管理系统</a></h1>
                                <nav id="fh5co-menu-wrap" role="navigation">
                                    <ul class="sf-menu" id="fh5co-primary-menu">
                                        <li>
                                            <a class="active" href="index.html">主页</a>
                                        </li>
                                        <li>
                                            <a href="hotel.html" class="fh5co-sub-ddown">房型</a>
                                            <ul class="fh5co-sub-menu">
                                                <li>
                                                    <a href="#">标准大床房</a>
                                                </li>
                                                <li>
                                                    <a href="#">标准双床房</a>
                                                </li>
                                                <li>
                                                    <a href="#">豪华大床房</a>
                                                </li>
                                                <li>
                                                    <a href="#">豪华双床房</a>
                                                </li>
                                                <li>
                                                    <a href="#">家庭亲子套房</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#" onclick="gotoSer()">我的</a>
                                        </li>
                                        <li>
                                            <a href="blog.html">图册</a>
                                        </li>
                                        <li>
                                            <a href="contact.html">关于我们</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </header>

                </div>
                <!-- end:fh5co-header -->
                <aside id="fh5co-hero" class="js-fullheight">
                    <div class="flexslider js-fullheight">
                        <ul class="slides">
                            <li style="background-image: url(static/images/slider1.jpg);">
                                <div class="overlay-gradient"></div>
                                <div class="container">
                                    <div class="col-md-12 col-md-offset-0 text-center slider-text">
                                        <div class="slider-text-inner js-fullheight">
                                            <div class="desc">
                                                <p><span>陈楚鑫 李洋志 翁跃 谭钧升</span></p>
                                                <h2>X酒店信息管理系统</h2>
                                                <p>
                                                    <a class="btn btn-primary btn-lg" href="<?php echo url('logintest/index'); ?>" id="up1">立即登录</a>
                                                    <input type="button" class="btn btn-primary btn-lg" id="out1" value="退出登录" />
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li style="background-image: url(static/images/slider2.jpg);">
                                <div class="overlay-gradient"></div>
                                <div class="container">
                                    <div class="col-md-12 col-md-offset-0 text-center slider-text">
                                        <div class="slider-text-inner js-fullheight">
                                            <div class="desc">
                                                <p><span>陈楚鑫 李洋志 翁跃 谭钧升</span></p>
                                                <h2>X酒店信息管理系统</h2>
                                                <p>
                                                    <a class="btn btn-primary btn-lg" href="<?php echo url('logintest/index'); ?>" id="up2">立即登录</a>
                                                    <input type="button" class="btn btn-primary btn-lg" id="out2" value="退出登录" />
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li style="background-image: url(static/images/slider3.jpg);">
                                <div class="overlay-gradient"></div>
                                <div class="container">
                                    <div class="col-md-12 col-md-offset-0 text-center slider-text">
                                        <div class="slider-text-inner js-fullheight">
                                            <div class="desc">
                                                <p><span>陈楚鑫 李洋志 翁跃 谭钧升</span></p>
                                                <h2>X酒店信息管理系统</h2>
                                                <p>
                                                    <a class="btn btn-primary btn-lg" href="<?php echo url('logintest/index'); ?>" id="up3">立即登录</a>
                                                    <input type="button" class="btn btn-primary btn-lg" id="out3" value="退出登录" />
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                </aside>
                <div class="wrap">
                    <div class="container">
                        <div class="row">
                            <div id="availability">
                                <form action=#>
                                    <div class="a-col">
                                        <section>
                                            <select class="cs-select cs-skin-border" id="room-type">
                                                <option value="" disabled selected>选择房型</option>
                                                <option value="stdsingle">标准大床房</option>
                                                <option value="stddouble">标准双床房</option>
                                                <option value="luxsingle">豪华大床房</option>
                                                <option value="luxdouble">豪华双人房</option>
                                                <option value="family">家庭亲子套房 </option>
                                            </select>
                                        </section>
                                    </div>
                                    <div class="a-col alternate">
                                        <div class="input-field">
                                            <label for="comeTimeSelecotor">入住时间</label>
                                            <input type="text" class="demo-input" placeholder="请选择日期" id="comeTimeSelecotor">
                                        </div>
                                    </div>
                                    <div class="a-col alternate">
                                        <div class="input-field">
                                            <label for="leaveTimeSelector">离开时间</label>
                                            <input type="text" class="demo-input" placeholder="" id="leaveTimeSelector" />
                                        </div>
                                    </div>

                                    <div class="a-col">
                                        <section>
                                            <div class="input-field">
                                                <select class="cs-select cs-skin-border" id="guest-number">
                                                    <option value="" disabled selected>选择人数</option>
                                                    <option value="1a0c">1成人</option>
                                                    <option value="2a0c">2成人</option>
                                                    <option value="1a1c">1成人 1儿童</option>
                                                    <option value="2a1c">2成人 1儿童</option>
                                                </select>
                                            </div>
                                        </section>
                                    </div>

                                    <!--注意这里写跳转参数-->
                                    <div class="a-col action">

                                        <!--<a href="<?php echo url('/search/index'); ?>" onclick="ajaxPost()">-->
                                        <a onclick="ajaxPost()">
                                            <span> 立即查询</span>
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="featured-hotel" class="fh5co-bg-color">
                    <div class="container">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-title text-center">
                                    <h2>精选房型推荐</h2>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="feature-full-1col">
                                <div class="image" style="background-image: url(static/images/hotel_feture_1.jpg);">
                                    <div class="descrip text-center">
                                        <p><small>价格</small><span>$100/晚</span></p>
                                    </div>
                                </div>
                                <div class="desc">
                                    <h3>豪华大床房</h3>
                                    <p>房型描述 </p>
                                    <p>
                                        <a href="#" class="btn btn-primary btn-luxe-primary">立刻预订<i class="ti-angle-right"></i></a>
                                    </p>
                                </div>
                            </div>

                            <div class="feature-full-2col">
                                <div class="f-hotel">
                                    <div class="image" style="background-image: url(static/images/hotel_feture_2.jpg);">
                                        <div class="descrip text-center">
                                            <p><small>价格</small><span>$99/晚</span></p>
                                        </div>
                                    </div>
                                    <div class="desc">
                                        <h3>家庭亲子套房</h3>
                                        <p>房型描述 </p>
                                        <p>
                                            <a href="#" class="btn btn-primary btn-luxe-primary">立刻预订 <i class="ti-angle-right"></i></a>
                                        </p>
                                    </div>
                                </div>
                                <div class="f-hotel">
                                    <div class="image" style="background-image: url(static/images/hotel_feture_3.jpg);">
                                        <div class="descrip text-center">
                                            <p><small>价格</small><span>$99/晚</span></p>
                                        </div>
                                    </div>
                                    <div class="desc">
                                        <h3>复式套房</h3>
                                        <p>房型描述 </p>
                                        <p>
                                            <a href="#" class="btn btn-primary btn-luxe-primary">立刻预订 <i class="ti-angle-right"></i></a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div id="hotel-facilities">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-title text-center">
                                    <h2>我们的特色</h2>
                                </div>
                            </div>
                        </div>

                        <div id="tabs">
                            <nav class="tabs-nav">
                                <a href="#" class="active" data-tab="tab1">
                                    <i class="flaticon-restaurant icon"></i>
                                    <span>餐饮</span>
                                </a>
                                <a href="#" data-tab="tab2">
                                    <i class="flaticon-cup icon"></i>
                                    <span>吧台</span>
                                </a>
                                <a href="#" data-tab="tab3">

                                    <i class="flaticon-car icon"></i>
                                    <span>停车场</span>
                                </a>
                                <a href="#" data-tab="tab4">

                                    <i class="flaticon-swimming icon"></i>
                                    <span>游泳池</span>
                                </a>
                                <a href="#" data-tab="tab5">

                                    <i class="flaticon-massage icon"></i>
                                    <span>桑拿</span>
                                </a>
                                <a href="#" data-tab="tab6">

                                    <i class="flaticon-bicycle icon"></i>
                                    <span>健身房</span>
                                </a>
                            </nav>
                            <div class="tab-content-container">
                                <div class="tab-content active show" data-tab-content="tab1">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_1.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">餐饮</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab-content="tab2">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_2.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">吧台</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab-content="tab3">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_3.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">停车场</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab-content="tab4">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_4.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">游泳池</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab-content="tab5">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_5.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">桑拿</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" data-tab-content="tab6">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="static/images/tab_img_6.jpg" class="img-responsive" alt="Image">
                                            </div>
                                            <div class="col-md-6">
                                                <span class="super-heading-sm">特色之一</span>
                                                <h3 class="heading">健身房</h3>
                                                <p>描述段落1</p>
                                                <p>描述段落2</p>
                                                <p class="service-hour">
                                                    <span>服务时间段</span>
                                                    <strong>7:30 AM - 8:00 PM</strong>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="testimonial">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-title text-center">
                                    <h2>历史评价</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="testimony">
                                    <blockquote>
                                        &ldquo;666啊&rdquo;
                                    </blockquote>
                                    <p class="author"><cite>张三</cite></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="testimony">
                                    <blockquote>
                                        &ldquo;五星好评&rdquo;
                                    </blockquote>
                                    <p class="author"><cite>李四</cite></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="testimony">
                                    <blockquote>
                                        &ldquo;还阔以&rdquo;
                                    </blockquote>
                                    <p class="author"><cite>王五</cite></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="fh5co-blog-section">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-title text-center">
                                    <h2>我们的风景</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="blog-grid" style="background-image: url(static/images/image-1.jpg);">
                                    <div class="date text-center">
                                        <span>30</span>
                                        <small>Sep</small>
                                    </div>
                                </div>
                                <div class="desc">
                                    <h3><a href="#">风景描述</a></h3>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="blog-grid" style="background-image: url(static/images/image-2.jpg);">
                                    <div class="date text-center">
                                        <span>30</span>
                                        <small>Sep</small>
                                    </div>
                                </div>
                                <div class="desc">
                                    <h3><a href="#">风景描述</a></h3>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="blog-grid" style="background-image: url(static/images/image-3.jpg);">
                                    <div class="date text-center">
                                        <span>30</span>
                                        <small>Sep</small>
                                    </div>
                                </div>
                                <div class="desc">
                                    <h3><a href="#">风景描述</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <footer id="footer" class="fh5co-bg-color">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="copyright">
                                    <p><small>&copy; 2018 数据库课设  
                                    <br> All Rights Reserved. 
                                    <br>by 陈楚鑫 李洋志 翁跃 谭钧升
                                </div>
                            </div>
                        </div>
                        <a href="#" id="delete">删除cookie</a>                
                    </div>
                </div>
            </div>
        </footer>

    </div>
    <!-- END fh5co-page -->

</div>
<!-- END fh5co-wrapper -->

<!-- Javascripts -->
<script src="static/js/jquery-2.1.4.min.js"></script>
<!-- Dropdown Menu -->
<script src="static/js/hoverIntent.js"></script>
<script src="static/js/superfish.js"></script>
<!-- Bootstrap -->
<script src="static/js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="static/js/jquery.waypoints.min.js"></script>
<!-- Counters -->
<script src="static/js/jquery.countTo.js"></script>
<!-- Stellar Parallax -->
<script src="static/js/jquery.stellar.min.js"></script>
<!-- Owl Slider -->
<!-- // <script src="js/owl.carousel.min.js"></script> -->
<!-- Date Picker -->
<script src="static/js/bootstrap-datepicker.min.js"></script>
<!-- CS Select -->
<script src="static/js/classie.js"></script>
<script src="static/js/selectFx.js"></script>
<!-- Flexslider -->
<script src="static/js/jquery.flexslider-min.js"></script>

<script src="static/js/custom.js"></script>

</body>
</html>
<script type="text/javascript">
    $('#out1').hide();
    $('#out2').hide();
    $('#out3').hide();
    var up1 = document.querySelector('#up1');
    var up2 = document.querySelector('#up2');
    var up3 = document.querySelector('#up3');
    var login = document.querySelector('#login');
    var del = document.querySelector('#delete');
    if(getCookie('loginstatus')){
        $('#up1').hide();
        $('#up2').hide();
        $('#up3').hide();
        $('#out1').show();
        $('#out2').show();
        $('#out3').show();
    }
    
    del.onclick = function(){
        removeCookie('loginstatus');
        $('#out1').hide();
        $('#out2').hide();
        $('#out3').hide();
        $('#up1').show();
        $('#up2').show();
        $('#up3').show();
        alert("已清除cookie！");
    }
    out1.onclick = function(){
        removeCookie('loginstatus');
        $('#out1').hide();
        $('#out2').hide();
        $('#out3').hide();
        $('#up1').show();
        $('#up2').show();
        $('#up3').show();
        alert("已退出登录！");
    }
    out2.onclick = function(){
        removeCookie('loginstatus');
        $('#out1').hide();
        $('#out2').hide();
        $('#out3').hide();
        $('#up1').show();
        $('#up2').show();
        $('#up3').show();
        alert("已退出登录！");
    }
    out3.onclick = function(){
        removeCookie('loginstatus');
        $('#out1').hide();
        $('#out2').hide();
        $('#out3').hide();
        $('#up1').show();
        $('#up2').show();
        $('#up3').show();
        alert("已退出登录！");
    }
    function getCookie(){
        var arr1 = document.cookie.split(';');
            for(var i = 0;i< arr1.length;i++){
                var arr2 = arr1[i].split('=');
                if(arr2[1] == '1'){
                    return arr2[1];
                } 
        }
    }
    function getId(key){
        var arr1 = document.cookie.split(';');
            for(var i = 0;i< arr1.length;i++){
                var arr2 = arr1[i].split('=');
                if(arr2[0] == key){
                    return arr2[1];
                }
        }
    }
    function removeCookie(key){
        setCookie(key,'',-1);
        setCookie('card_id','',-1);
    }
    function setCookie(c_name,value,expiredays)
    {
        var exdate=new Date();
        exdate.setDate(exdate.getDate()+expiredays);
        document.cookie=c_name+ "=" +escape(value)+
        ((expiredays==null) ? "" : ";expires="+exdate.toGMTString()+";path=/");
    }
    function gotoSer(){
    	if(getCookie('loginstatus')){
        window.location.href="../../../../cx/services.php";
	    }else{
	    	alert("未登录！即将跳转去登录页面！")
	    	var path = "<?php echo url('/index/logintest/index'); ?>";
            document.location = path;
	    }
    	
    }
</script>