<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/27
 * Time: 15:06
 */
include("../conn.php");
if ($_POST) {
    $op = $_POST["op_search"];
    switch ($op) {
        case 1://在editjob里面查询职位信息
            {
                $search_job_name = $_POST["search_job_name"];
                $query_search_job_name = "SELECT salary FROM job WHERE job_name='$search_job_name'";
                $tmp_salary = mysqli_query($link, $query_search_job_name);
                $row = mysqli_fetch_array($tmp_salary);
//               var_dump( $row["salary"]);
                $search_salary = $row["salary"];
                echo "
                        <table>
                        <tr>
                        <th>职位</th>
                        <th>工资</th>
                        </tr>
                        <tr>
                        <th> $search_job_name</th>
                        <th> $search_salary </th>
</tr>
                        </table>";
                echo "<a href='EditJob.php'><input type='button' value='返回上一页'></a>";
                break;
            }
        case 2://在editstuff里面查询员工信息
            {
                //首选获得所有的职位信息
                $query_job = "SELECT job_id,job_name FROM job ORDER BY job_id DESC";
                $tmp_job = mysqli_query($link, $query_job);
                $result = mysqli_fetch_array($tmp_job);
                $job_id = array($result["job_id"]);
                $job_name = array($result["job_name"]);
                while ($row = mysqli_fetch_array($tmp_job)) {
                    $job_id = array_merge(array($row["job_id"]), $job_id);
                    $job_name = array_merge(array($row["job_name"]), $job_name);
                }
                $job_key_id = array_combine($job_id, $job_name);
                $job_key_name = array_combine($job_name, $job_id);
//                var_dump($job);

                $search_stuff_type = $_POST["search_stuff_type"];
                $search_stuff = $_POST["search_stuff"];
                if ($search_stuff_type == 1) {
                    $query_search_stuff = "SELECT * FROM stuff WHERE stuff_id='$search_stuff'";

                }
                if ($search_stuff_type == 2) {
                    $query_search_stuff = "SELECT * FROM stuff WHERE stuff_name LIKE '$search_stuff' ORDER BY stuff_id ASC";

                }
                if ($search_stuff_type == 3) {
                    $tmp_job_id = $job_key_name[$search_stuff];
//                    var_dump($tmp_job_id);
                    $query_search_stuff = "SELECT * FROM stuff WHERE job_id = '$tmp_job_id' ORDER BY stuff_id ASC";
                }
                $tmp_search_stuff = mysqli_query($link, $query_search_stuff);
//                $result_stuff=mysqli_fetch_array($tmp_search_stuff);
//                var_dump($result_stuff["stuff_name"]);
                echo "<table>
<tr>
<th>ID</th>
<th>姓名</th>
<th>性别</th>
<th>联系方式</th>
<th>卡号</th>
<th>入职时间</th>
<th>职位</th>
<th>生日</th>
</tr>";
//                for($i=1;$i<=count())
                while ($row = mysqli_fetch_array($tmp_search_stuff)) {
//                    var_dump($row);
                    echo "<tr>";
                    echo "<th>" . $row['stuff_id'] . "</th>";
                    echo "<th>" . $row['stuff_name'] . "</th>";
                    if ($row['sex'] == 0) {
                        echo "<th>female</th>";
                    }
                    if ($row['sex'] == 1) {
                        echo "<th>male</th>";
                    }
                    echo "<th>" . $row['phone'] . "</th>";
                    echo "<th>" . $row['card'] . "</th>";
                    echo "<th>" . $row['join_time'] . "</th>";
                    echo "<th>" . $job_key_id[$row['job_id']] . "</th>";
                    echo "<th>" . $row['birth_time'] . "</th>";
                    echo "</tr>";
                }
                echo "</table>";

                echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                break;
            }
        default:
            {
                break;
            }
    }
}
?>