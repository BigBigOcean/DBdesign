<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"G:\phpStudy\PHPTutorial\WWW\tp5\public/../application/thanks\view\index\thanks.html";i:1545310310;}*/ ?>
<!doctype html>
<html lang="en">
<head>
	<script type="text/javascript"> 
		function countDown(secs,surl){ 
		//alert(surl); 
		var jumpTo = document.getElementById('jumpTo');
		jumpTo.innerHTML=secs; 
		if(--secs>0){ 
			setTimeout("countDown("+secs+",'"+surl+"')",1000); 
		}
		else
		{  
			location.href=surl; 
		} 
	} 
    </script>

    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script>
        function findindex(data)
        {
            for(var ii=0; ii<data.length; ii++)
            {
                if(data.charAt(ii)=='?') return ii;
            }
        }

        function jumpToDetail()
        {
            var wyurl = this.location;
            wyurl = wyurl.toString();
            var index = findindex(wyurl);
            var data = wyurl.slice(index+1, wyurl.length-5);
            //alert(data);
            var path = "<?php echo url('/detail/index?" + data + "'); ?>";
            //alert(path);
            document.location = path;
        }

    </script>

    <title>LuxuryHotel a Hotel Template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Rubik:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="../static/css/thanks/bootstrap.css">
    <link rel="stylesheet" href="../static/css/thanks/animate.css">
    <link rel="stylesheet" href="../static/css/thanks/owl.carousel.min.css">

    <link rel="stylesheet" href="../static/fonts/thanks/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="../static/fonts/thanks/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../static/css/thanks/magnific-popup.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="../static/css/thanks/style.css">
</head>

<body><span id="jumpTo" hidden="true">10</span>
<script type="text/javascript">
countDown(10,'//localhost:81/tp5/public/');
</script>

<header role="banner">

    <nav class="navbar navbar-expand-md navbar-dark bg-light">
        <div class="container">
            <a class="navbar-brand" >LuxuryHotel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample05" aria-controls="navbarsExample05" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
                <ul class="navbar-nav ml-auto pl-lg-5 pl-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.html">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="rooms.html" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Rooms</a>
                        <div class="dropdown-menu" aria-labelledby="dropdown04">
                            <a class="dropdown-item" href="rooms.html">Room Videos</a>
                            <a class="dropdown-item" href="rooms.html">Presidential Room</a>
                            <a class="dropdown-item" href="rooms.html">Luxury Room</a>
                            <a class="dropdown-item" href="rooms.html">Deluxe Room</a>
                        </div>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.html">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.html">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html">Contact</a>
                    </li>

                    <li class="nav-item cta">
                        <a class="nav-link" ><span>Book Now</span></a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
</header>
<!-- END header -->

<section class="site-hero overlay" data-stellar-background-ratio="0.5" style="background-image: url(../static/images/big_image_1.jpg);">
    <div class="container">
        <div class="row align-items-center site-hero-inner justify-content-center">
            <div class="col-md-12 text-center">

                <div class="mb-5 element-animate">
                    <h1>预订成功</h1>
                    <p>我们期待与您相遇</p>
					<!-- <p2>正在跳回首页</p2> -->
                    <p><a  class="btn btn-primary" onclick=jumpToDetail()>查看订单详情</a></p>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END section -->



</div>
</div>
</div>
</footer>
<!-- END footer -->

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="../static/js/thanks/jquery-3.2.1.min.js"></script>
<script src="../static/js/thanks/jquery-migrate-3.0.0.js"></script>
<script src="../static/js/thanks/popper.min.js"></script>
<script src="../static/js/thanks/bootstrap.min.js"></script>
<script src="../static/js/thanks/owl.carousel.min.js"></script>
<script src="../static/js/thanks/jquery.waypoints.min.js"></script>
<script src="../static/js/thanks/jquery.stellar.min.js"></script>

<script src="../static/js/thanks/jquery.magnific-popup.min.js"></script>
<script src="../static/js/thanks/magnific-popup-options.js"></script>

<script src="../static/js/thanks/main.js"></script>
</body>
</html>