<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"G:\phpStudy\PHPTutorial\WWW\tp5\public/../application/index\view\regist\index.html";i:1545470529;}*/ ?>
<!DOCTYPE HTML>
<html>
<script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
<script>
	var searchResult = null;
	function ajaxPost() {
		var customer_name = $("#user").val();
		var sexchoice = document.getElementsByName('sex');
		for (var i = 0, length = sexchoice.length; i < length; i++) {
			if (sexchoice[i].checked) {
				var sex=sexchoice[i].value;
				break;
			}
		}
		var password1 = $("#password1").val();
		var card_id = $("#userid").val();
		//var join_time=CURRENT_TIMESTAMP;
		$.ajax({
			type: "post",
			url: "<?php echo url('Search/index/doRegist'); ?>",
			data: {
				customer_name: customer_name,
				sex: sex,
				password1: password1,
				card_id: card_id,
				card_type: '1'//默认全部都是身份证
				//join_time: join_time
			},
			success: function(data) {
				searchResult = JSON.stringify(data);
				registS();
			},
			error:function(error){
				registE();
			}
		});
	}
</script>
	<head>
		<title>登录页面</title>
		<link href="../../static/css/logintest/style.css" rel="stylesheet" type="text/css" media="all" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<!-- -->
		<script src="../../static/js/jquery.min.js"></script>

	</head>

	<body>
		<!-- contact-form -->
		<div class="message warning">
			<div class="inset">
				<div class="login-head">
					<h1>X酒店登录系统</h1>
				</div>
				<form >
					<li>
						<input id="user" type="text" class="text" value="您的姓名" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '您的姓名';}">
					</li>
					<div class="clear"> </div>
					<li>
					<label><input type="radio" name="sex" value="0" />男&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label> 
					<label><input type="radio" name="sex" value="1" />女 </label> 
					</li>
					<div class="clear"> </div>
					<li>
						<input id="userid" type="text" class="text" value="您的证件号码" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '您的证件号码';}">
					</li>
					<div class="clear"> </div>
					<li>
						<input id="password1" type="password" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'password';}">
					</li>
					<div class="clear"> </div>
						<input type="button" id="login" value="注册">
						<div class="clear"> </div>

				</form>
			</div>
		</div>
		</div>
		<div class="clear"> </div>
		<!--- footer --->
	<!--	<div class="footer">
			<p>&copy; 2018 数据库课设 <br> All Rights Reserved. <br>by 陈楚鑫 李洋志 翁跃 谭钧升</p>
		</div>-->

	</body>

</html>

<script type="text/javascript">
	var login = document.querySelector('#login');
	var user = document.querySelector('#user')

	login.onclick = function() {
		var reg = /^[0-9]*$/;
		if (!reg.test($("#userid").val())) {
			alert("请输入正确证件号码！")
		}else{
			ajaxPost();
		}
	}
	function registS(){
		setCookie('card_id', user.value, 5);
		setCookie('loginstatus', '1', 5);
		alert("注册成功！欢迎立即登录！");
		window.location.href=document.referrer;
	}
	
	function registE(){
		alert("信息填写有误！注册失败！请重新填写！");
	}
	function getCookie(key) {
		var arr1 = document.cookie.split(';');
		for(var i = 0; i < arr1.length; i++) {
			var arr2 = arr1[i].split('=');
			if(arr2[0] == key) {
				return arr2[1];
			}
		}
	}

	function setCookie(c_name, value, expiredays) {
		var exdate = new Date();
		exdate.setDate(exdate.getDate() + expiredays);
		document.cookie = c_name + "=" + escape(value) +
			((expiredays == null) ? "" : ";expires=" + exdate.toGMTString() + ";path=/");
	}
</script>
<!--ajax交互-->
