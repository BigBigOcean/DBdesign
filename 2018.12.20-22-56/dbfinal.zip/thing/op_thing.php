<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/20
 * Time: 21:04
 */

//edittype所有操作op从1到25
include("../conn.php");
//创建新的物品类型
$op = $_POST["op"];
switch ($op) {
    //从edittype加入新的物品类型
    case 1:
        {
            $thing_name = $_POST["thing_name"];
            $thing_num = $_POST["thing_num"];
            $position = $_POST["position"];
            $repairphone = $_POST["repairphone"];
            $remark = $_POST["remark"];
//insert
            $query_select_max = "SELECT MAX(thing_id) FROM originalthing ";
            $max_thingid = mysqli_query($link, $query_select_max);
            $thing_id;
            while ($row = mysqli_fetch_array($max_thingid)) {
                $thing_id = $row['MAX(thing_id)'] + 1;
            }
            $query_thingtype = "INSERT INTO originalthing(thing_id,thing_name,thing_num,position,repairphone,remark)
                              VALUES('$thing_id','$thing_name','$thing_num','$position','$repairphone','$remark')";

            if (!mysqli_query($link, $query_thingtype)) {
                echo "<a href='EditType.php'><input type='button' value='返回上一页'> </a><br/>";
                die('Error: ' . mysqli_error($link));
            } else {
                header("location:EditType.php");
            }
            break;
        }
    case 2://从edittype删除物品
        {
            $delete_thing_id = $_POST["delete_thing_name"];
            $query_delete_thing = "DELETE FROM originalthing WHERE thing_id='$delete_thing_id'";
            if (!mysqli_query($link, $query_delete_thing)) {
                echo "<a href='EditType.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                header("location:EditType.php");
            }
            break;
        }
    case 26:
        {

            $thing_id = $_POST["thing_id"];
//            var_dump($thing_id);
            $room_id = $_POST["room_id"];
            $thing_status = $_POST["thing_status"];
            $query_add_thing = "INSERT INTO thing(thing_id,room_id,thing_status)
                              VALUES('$thing_id','$room_id','$thing_status')";
            if (!mysqli_query($link, $query_add_thing)) {
                echo "<a href='EditThing.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                header("location:EditThing.php");
            }
            break;
        }
    case 27:
        {
            $thing_id = $_POST["thing_id"];
            $room_id = $_POST["room_id"];
            $thing_status=$_POST["thing_status"];
            $query_edit_thing="UPDATE thing SET thing_status=".$thing_status." WHERE thing_id = ".$thing_id." AND room_id = ".$room_id."";
            if(!mysqli_query($link,$query_edit_thing))
            {
                echo '<form id="form" name="form" method="post" action="search.php">
                            <input type="hidden" name="op_search"  value="27"/>
                            <input type="hidden" name="search_room_id" value='.$room_id.'>
                            <input type="submit" value="返回上一页">
                        </form>
                     ';
                die("Error: " . mysqli_error($link));
            }
            else
            {
                echo '<form id="form" name="form" method="post" action="search.php">
                            <input type="hidden" name="op_search"  value="27"/>
                            <input type="hidden" name="search_room_id" value='.$room_id.'>
                        </form>
                     <script   language="javascript">
                        document.form.submit()
                     </script>
                     ';
            }
            break;
        }
    case 28:
        {
            $delete_thing_id = $_POST["delete_thing_id"];
            $delete_room_id = $_POST["delete_room_id"];
            $query_delete_thing = "DELETE FROM thing WHERE thing_id='$delete_thing_id' AND room_id='$delete_room_id'";
            if (!mysqli_query($link, $query_delete_thing)) {
                echo "<a href='EditThing.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);

                //回到上一页并且保留原本的房号查询信息
                echo '<form id="form" name="form" method="post" action="search.php">
                            <input type="hidden" name="op_search"  value="27"/>
                            <input type="hidden" name="search_room_id" value='.$delete_room_id.'>
                        </form>
                     <script   language="javascript">
                        document.form.submit()
                     </script>
                     ';
            }
            break;
        }
    case 29:
        {

            $thing_id = $_POST["thing_id"];
//            var_dump($thing_id);
            $room_id = $_POST["room_id"];
            $thing_status = $_POST["thing_status"];
            $query_add_thing = "INSERT INTO thing(thing_id,room_id,thing_status)
                              VALUES('$thing_id','$room_id','$thing_status')";
            if (!mysqli_query($link, $query_add_thing)) {
                echo "<a href='EditThing.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                echo '<form id="form" name="form" method="post" action="search.php">
                            <input type="hidden" name="op_search"  value="27"/>
                            <input type="hidden" name="search_room_id" value='.$room_id.'>
                        </form>
                     <script   language="javascript">
                        document.form.submit()
                     </script>
                     ';
            }
            break;
        }
    case 49:
        {
            $query_select_originalthing = "SELECT * FROM originalthing ORDER BY thing_id ASC";
            $select_originalthing = mysqli_query($link, $query_select_originalthing);
//                var_dump($select_thing);
            $result = mysqli_fetch_array($select_originalthing);
            $result_thing_id = array($result["thing_id"]);
            $result_thing_name = array($result["thing_name"]);
            $result_thing_num = array($result["thing_num"]);
            $result_position = array($result["position"]);
            $result_repairphone = array($result["repairphone"]);
            $result_remark = array($result["remark"]);
            while ($row = mysqli_fetch_array($select_originalthing)) {
                $row_thing_id = array($row["thing_id"]);
                $row_thing_name = array($row["thing_name"]);
                $row_thing_num = array($row["thing_num"]);
                $row_position = array($row["position"]);
                $row_repairphone = array($row["repairphone"]);
                $row_remark = array($row["remark"]);
//                    var_dump($row);
                $result_thing_id = array_merge($result_thing_id, $row_thing_id);
                $result_thing_name = array_merge($result_thing_name, $row_thing_name);
                $result_thing_num = array_merge($result_thing_num, $row_thing_num);
                $result_position = array_merge($result_position, $row_position);
                $result_repairphone = array_merge($result_repairphone, $row_repairphone);
                $result_remark = array_merge($result_remark, $row_remark);
//                    echo "<hr/>";
            }
//                echo "<hr/>";
            $result_thing_id = implode(",", $result_thing_id);
            $result_thing_name = implode(",", $result_thing_name);
            $result_thing_num = implode(",", $result_thing_num);
//            var_dump($result_thing_num);
            $result_position = implode(",", $result_position);
            $result_repairphone = implode(",", $result_repairphone);
            $result_remark = implode(",", $result_remark);
//                var_dump($result_salary);
//               var_dump($result_thing_name);
//               $result=explode(",",$result);
//               var_dump($result);
//
            mysqli_close($link);
            echo '<form  name="form" method="post" action="EditThing.php">
<input type="hidden" name="op"  value="50"/>
  <input type="hidden" name="select_thing_id"  value="' . $result_thing_id . '"/>
  <input type="hidden" name="select_thing_name"  value="' . $result_thing_name . '"/>
  <input type="hidden" name="select_thing_num"  value="' . $result_thing_num . '"/>
  <input type="hidden" name="select_position"  value="' . $result_position . '"/>
  <input type="hidden" name="select_repairphone"  value="' . $result_repairphone . '"/>
  <input type="hidden" name="select_remark"  value="' . $result_remark . '"/>
                  <script   language="javascript">
                document.form.submit();
  </script>
</form>
';
            break;
        }
    case 50://查询所有物品返回edittype
        {
            $query_select_originalthing = "SELECT * FROM originalthing ORDER BY thing_id ASC";
            $select_originalthing = mysqli_query($link, $query_select_originalthing);
//                var_dump($select_thing);
            $result = mysqli_fetch_array($select_originalthing);
            $result_thing_id = array($result["thing_id"]);
            $result_thing_name = array($result["thing_name"]);
            $result_thing_num = array($result["thing_num"]);
            $result_position = array($result["position"]);
            $result_repairphone = array($result["repairphone"]);
            $result_remark = array($result["remark"]);
            while ($row = mysqli_fetch_array($select_originalthing)) {
                $row_thing_id = array($row["thing_id"]);
                $row_thing_name = array($row["thing_name"]);
                $row_thing_num = array($row["thing_num"]);
                $row_position = array($row["position"]);
                $row_repairphone = array($row["repairphone"]);
                $row_remark = array($row["remark"]);
//                    var_dump($row);
                $result_thing_id = array_merge($result_thing_id, $row_thing_id);
                $result_thing_name = array_merge($result_thing_name, $row_thing_name);
                $result_thing_num = array_merge($result_thing_num, $row_thing_num);
                $result_position = array_merge($result_position, $row_position);
                $result_repairphone = array_merge($result_repairphone, $row_repairphone);
                $result_remark = array_merge($result_remark, $row_remark);
//                    echo "<hr/>";
            }
//                echo "<hr/>";
            $result_thing_id = implode(",", $result_thing_id);
            $result_thing_name = implode(",", $result_thing_name);
            $result_thing_num = implode(",", $result_thing_num);
//            var_dump($result_thing_num);
            $result_position = implode(",", $result_position);
            $result_repairphone = implode(",", $result_repairphone);
            $result_remark = implode(",", $result_remark);
//                var_dump($result_salary);
//               var_dump($result_thing_name);
//               $result=explode(",",$result);
//               var_dump($result);
//
            mysqli_close($link);
            echo '<form  name="form" method="post" action="EditType.php">
<input type="hidden" name="op"  value="50"/>
  <input type="hidden" name="select_thing_id"  value="' . $result_thing_id . '"/>
  <input type="hidden" name="select_thing_name"  value="' . $result_thing_name . '"/>
  <input type="hidden" name="select_thing_num"  value="' . $result_thing_num . '"/>
  <input type="hidden" name="select_position"  value="' . $result_position . '"/>
  <input type="hidden" name="select_repairphone"  value="' . $result_repairphone . '"/>
  <input type="hidden" name="select_remark"  value="' . $result_remark . '"/>
                  <script   language="javascript">
                document.form.submit();
  </script>
</form>
';
            break;
        }
    default:
        {
            echo "Error: illegal get into this page";
        }

}


mysqli_close($link);

//echo "<script>window.location.href='AddNewThingType.php'</script>";
?>