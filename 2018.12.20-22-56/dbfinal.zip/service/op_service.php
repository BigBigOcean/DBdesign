<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/20
 * Time: 22:58
 */
include("../conn.php");
if ($_POST) {
    $op = $_POST["op"];

    switch ($op) {
        case 1://editservice增加新职位
            {
                $query_select_max = "SELECT MAX(service_id) FROM service ";
                $max_service_id = mysqli_query($link, $query_select_max);
                while ($row = mysqli_fetch_array($max_service_id)) {
                    $service_id = $row['MAX(service_id)'] + 1;
                }
                $service_name = $_POST["service_name"];
                $price = $_POST["price"];
                $remark=$_POST["remark"];
                $query_add_new_service = "INSERT INTO service(service_id,service_name,price,remark) 
VALUES('$service_id','$service_name','$price','$remark')";
                if (!mysqli_query($link, $query_add_new_service)) {
                    echo "<a href='EditService.php'><input type='button' value='返回上一页'> </a><br/>";
                    die("Error: " . mysqli_error($link));

                } else {
                    mysqli_close($link);
                    header("location:EditService.php");
                }
                break;
            }
        case 2://查询服务信息返回去editservice
            {
//                echo "test";
                $query_select_service = "SELECT * FROM service";
                $select_service = mysqli_query($link, $query_select_service);
//                var_dump($select_service);
                $result = mysqli_fetch_array($select_service);
                $result_service_id = array($result["service_id"]);
                $result_service_name = array($result["service_name"]);
                $result_price = array($result["price"]);
                $result_remark = array($result["remark"]);

                while ($row = mysqli_fetch_array($select_service)) {
                    $row_service_id = array($row["service_id"]);
                    $row_service_name = array($row["service_name"]);
                    $row_price = array($row["price"]);
                    $row_remark = array($row["remark"]);
//                    var_dump($row);
                    $result_service_id = array_merge($result_service_id, $row_service_id);
                    $result_service_name = array_merge($result_service_name, $row_service_name);
                    $result_price = array_merge($result_price, $row_price);
                    $result_remark = array_merge($result_remark, $row_remark);
//
                }
                $result_service_id = implode(",", $result_service_id);
                $result_service_name = implode(",", $result_service_name);
                $result_price = implode(",", $result_price);
                $result_remark = implode(",", $result_remark);

                mysqli_close($link);
                echo '<form  name="form" method="post" action="Editservice.php">
<input type="hidden" name="op"  value="2"/>
  <input type="hidden" name="select_service_name"  value="' . $result_service_name . '"/>
  <input type="hidden" name="select_service_id"  value="' . $result_service_id . '"/>
  <input type="hidden" name="select_price"  value="' . $result_price . '"/>
  <input type="hidden" name="select_remark"  value="' . $result_remark . '"/>
                  <script   language="javascript">
                document.form.submit();
  </script>
</form>
  
';

                break;
            }
        case 3://从editservice里面提交修改服务申请
            {
                $edit_service_id = $_POST["edit_service"];
                $edit_price = $_POST["edit_price"];
                $edit_remark = $_POST["edit_remark"];
                $query_edit_salary = "UPDATE service SET ";
                if($edit_price!="")
                {
                    $query_edit_salary=$query_edit_salary. " price = '$edit_price'";
                }
                if($edit_remark!="")
                {
                    $query_edit_salary=$query_edit_salary. " remark = '$edit_remark'";
                }
                $query_edit_salary=$query_edit_salary."WHERE service_id='$edit_service_id'";

                if (!mysqli_query($link, $query_edit_salary)) {
                    echo "<a href='EditService.php'><input type='button' value='返回上一页'> </a><br/>";
                    die("Error: " . mysqli_error($link));
                } else {
                    mysqli_close($link);
                    header("location:EditService.php");
                }
                break;
            }
        case 4://从editservice删除服务
            {
                $delete_service_id = $_POST["delete_service_name"];
                $query_delete_service = "DELETE FROM service WHERE service_id='$delete_service_id'";
                if (!mysqli_query($link, $query_delete_service)) {
                    echo "<a href='EditService.php'><input type='button' value='返回上一页'> </a><br/>";
                    die("Error: " . mysqli_error($link));
                } else {
                    mysqli_close($link);
                    header("location:EditService.php");
                }
                break;
            }
        case 5://找到所有的职位和员工信息，传回去 editstuff.php
            {
                $query_select_service = "SELECT service_id,service_name FROM service";
                $select_service = mysqli_query($link, $query_select_service);
//                var_dump($select_service);
                $result = mysqli_fetch_array($select_service);
                $result_service_id = array($result["service_id"]);
                $result_service_name = array($result["service_name"]);

                while ($row = mysqli_fetch_array($select_service)) {
                    $row_service_id = array($row["service_id"]);
                    $row_service_name = array($row["service_name"]);

//                    var_dump($row);
                    $result_service_id = array_merge($result_service_id, $row_service_id);
                    $result_service_name = array_merge($result_service_name, $row_service_name);

//                    echo "<hr/>";
                }
//                echo "<hr/>";
                $result_service_id = implode(",", $result_service_id);
                $result_service_name = implode(",", $result_service_name);

//               var_dump($result_service_name);
//               $result=explode(",",$result);
//               var_dump($result);
//
                //找到所有的员工信息并传回去editstuff.php
                $query_select_stuff = "SELECT stuff_id,stuff_name,sex,phone,card,join_time,service_id,birth_time FROM stuff  ORDER BY stuff_id ASC";
                $select_stuff = mysqli_query($link, $query_select_stuff);

                $result_stuff = mysqli_fetch_array($select_stuff);
                $result_stuff_id = array($result_stuff["stuff_id"]);
                $result_stuff_name = array($result_stuff["stuff_name"]);
                $result_sex = array($result_stuff["sex"]);
                $result_phone = array($result_stuff["phone"]);
                $result_card = array($result_stuff["card"]);
                $result_join_time = array($result_stuff["join_time"]);
                $result_stuff_service_id = array($result_stuff["service_id"]);
                $result_birth_time = array($result_stuff["birth_time"]);
                while ($row = mysqli_fetch_array($select_stuff)) {
                    $row_stuff_id = array($row["stuff_id"]);
                    $row_stuff_name = array($row["stuff_name"]);
                    $row_sex = array($row["sex"]);
                    $row_phone = array($row["phone"]);
                    $row_card = array($row["card"]);
                    $row_join_time = array($row["join_time"]);
                    $row_stuff_service_id = array($row["service_id"]);
                    $row_birth_time = array($row["birth_time"]);

                    $result_stuff_id = array_merge($result_stuff_id, $row_stuff_id);
                    $result_stuff_name = array_merge($result_stuff_name, $row_stuff_name);
                    $result_sex = array_merge($result_sex, $row_sex);
                    $result_phone = array_merge($result_phone, $row_phone);
                    $result_card = array_merge($result_card, $row_card);
                    $result_join_time = array_merge($result_join_time, $row_join_time);
                    $result_stuff_service_id = array_merge($result_stuff_service_id, $row_stuff_service_id);
                    $result_birth_time = array_merge($result_birth_time, $row_birth_time);
                }
                $result_stuff_id = implode(",", $result_stuff_id);
                $result_stuff_name = implode(",", $result_stuff_name);
                $result_sex = implode(",", $result_sex);
                $result_phone = implode(",", $result_phone);
                $result_card = implode(",", $result_card);
                $result_join_time = implode(",", $result_join_time);
                $result_stuff_service_id = implode(",", $result_stuff_service_id);
//                var_dump($result_stuff_service_id);
                $result_birth_time = implode(",", $result_birth_time);

                mysqli_close($link);
                echo '<form id="form" name="form" method="post" action="EditStuff.php">
  <input type="hidden" name="op"  value="5"/>
  <input type="hidden" name="select_service_id"  value="' . $result_service_id . '"/>
  <input type="hidden" name="select_service_name"  value="' . $result_service_name . '"/>
  
  <input type="hidden" name="select_stuff_id" value="' . $result_stuff_id . '"/>
  <input type="hidden" name="select_stuff_name" value="' . $result_stuff_name . '"/>
  <input type="hidden" name="select_sex" value="' . $result_sex . '"/>
  <input type="hidden" name="select_phone" value="' . $result_phone . '"/>
  <input type="hidden" name="select_card" value="' . $result_card . '"/>
  <input type="hidden" name="select_join_time" value="' . $result_join_time . '"/>
  <input type="hidden" name="select_stuff_service_id" value="' . $result_stuff_service_id . '"/>
  <input type="hidden" name="select_birth_time" value="' . $result_birth_time . '"/>
</form>
    <script   language="javascript">
  document.form.submit();
  </script>';
                break;
            }
        case 6://从editstuff里面增加新员工
            {
                $stuff_name = $_POST["stuff_name"];
                $sex = $_POST["sex"];
                $phone = $_POST["phone"];
                $card_id = $_POST["card_id"];
                $birth_time = $_POST["birth_time"];
                $selected_service = $_POST["selected_service"];
//                var_dump($stuff_name);
//                var_dump($sex);
//                var_dump($phone);
//                var_dump($card_id);
//                var_dump($birth_time);
//                var_dump($selected_service);

                $query_select_max = "SELECT MAX(stuff_id) FROM stuff ";
                $max_stuff_id = mysqli_query($link, $query_select_max);
                while ($row = mysqli_fetch_array($max_stuff_id)) {
                    $stuff_id = $row['MAX(stuff_id)'] + 1;
                }
//                echo $stuff_id;

                $query_add_new_stuff = "INSERT INTO stuff(stuff_id,stuff_name,sex,phone,card,service_id,birth_time) 
VALUES('$stuff_id','$stuff_name','$sex','$phone','$card_id','$selected_service','$birth_time')";
                if (!mysqli_query($link, $query_add_new_stuff)) {
//                    if($birth_time=="")
//                    {
//                        echo "haha";
//                        var_dump($birth_time);
//                    }

                    echo '<a href="EditStuff.php"><input type="button" value="返回上一页"></a>';
                    die ("Error: " . mysqli_error($link));
                } else {
                    mysqli_close($link);
                    header("location:EditStuff.php");
                }
                break;
            }
        case 7://从editstuff删除员工
            {
                $delete_stuff_id = $_POST["delete_stuff_id"];
                var_dump($delete_stuff_id);
                $query_delete_stuff = "DELETE FROM stuff WHERE stuff_id='$delete_stuff_id'";
                if (!mysqli_query($link, $query_delete_stuff)) {
                    echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                    die("Error: " . mysqli_error($link));
                } else {
                    mysqli_close($link);
                    header("location:EditStuff.php");
                }
                break;
            }
        case 8://从editstuff修改员工信息
            {
                $edit_stuff_id = $_POST["edit_stuff_id"];
                $edit_stuff_name = $_POST["edit_stuff_name"];
                $edit_stuff_sex = $_POST["edit_sex"];
                $edit_phone = $_POST["edit_phone"];
                $edit_card = $_POST["edit_card"];
                $edit_birth_time = $_POST["edit_birth_time"];
                if ($edit_stuff_name != "") {
                    $query_edit_stuff_name = "UPDATE stuff SET stuff_name = '$edit_stuff_name' WHERE stuff_id = '$edit_stuff_id'";
                    if (!mysqli_query($link, $query_edit_stuff_name)) {
                        echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                        die("Error: " . mysqli_error($link));
                    }
                }
                if ($edit_stuff_sex != "") {
                    $query_edit_sex = "UPDATE stuff SET sex='$edit_stuff_sex' WHERE stuff_id='$edit_stuff_id'";
                    if (!mysqli_query($link, $query_edit_sex)) {
                        echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                        die("Error: " . mysqli_error($link));
                    }
                }
                if ($edit_phone != "") {
                    $query_phone = "UPDATE stuff SET phone='$edit_phone' WHERE stuff_id='$edit_stuff_id'";
                    if (!mysqli_query($link, $query_phone)) {
                        echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                        die("Error: " . mysqli_error($link));
                    }
                }
                if ($edit_card != "") {
                    $query_card = "UPDATE stuff SET card='$edit_card' WHERE stuff_id='$edit_stuff_id'";
                    if (!mysqli_query($link, $query_card)) {
                        echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                        die("Error: " . mysqli_error($link));
                    }
                }
                if ($edit_birth_time != "") {
                    $query_edit_sex = "UPDATE stuff SET birth_time='$edit_birth_time' WHERE stuff_id='$edit_stuff_id'";
                    if (!mysqli_query($link, $query_edit_sex)) {
                        echo "<a href='EditStuff.php'><input type='button' value='返回上一页'></a>";
                        die("Error: " . mysqli_error($link));
                    }
                }
//                mysqli_close($link);
                header("location:EditStuff.php");
                break;
            }
        case 9:
            {

            }
        default:
            {
                break;
            }
    }
}


mysqli_close($link);
?>