﻿$(document).ready(function(){
	var publicw;
	var w=screen.width;
	var h=screen.height;
	var Ifw= document.documentElement.clientWidth
      || document.body.clientWidth;
    var htmlh = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    var htmlw = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      if(htmlw<=1000){
      publicw=1000;
      }
    else{
    	publicw=w;
    } 
    var right_content=document.getElementById("right_content");
	if(right_content!=null){
		right_content.style.width=(w-240-17)+"px";
	}
	var all=document.getElementById("all");
	if(all!=null){
		all.style.width=(w-17)+"px";
	}
// var top=document.getElementById("top");
//	if(top!=null){
//		top.style.width=(w-17)+"px";
//	}
//	 var content_right=document.getElementById("content_right");
//	if(content_right!=null){
//		content_right.style.width=(w-147)+"px";
//	}
//	 var content=document.getElementById("content");
//	if(content!=null){
//		content.style.width=(w-17)+"px";
//	}
//	
//	var content_left=document.getElementById("content_left");
//	if(content_right.offsetHeight<727){
//		content_left.style.height='727px';
//		content_right.style.height='727px';
//	}else{
//		content_left.style.height=content_right.offsetHeight+"px";
//	}
})


