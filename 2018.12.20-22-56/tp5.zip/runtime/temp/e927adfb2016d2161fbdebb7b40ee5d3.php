<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\tp5\public/../application/index\view\index\goods.html";i:1539693202;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <form action="insert" method="post">
        <table>
            <tr>
                <td>用户名</td>
                <td><input type="text" name="u_name"></td>
            </tr>
            <tr>
                <td>密码</td>
                <td><input type="text" name="u_pwd"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="提交"></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>