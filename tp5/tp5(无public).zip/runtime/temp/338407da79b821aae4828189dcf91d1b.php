<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpstudy\PHPTutorial\WWW\tp5\public/../application/search\view\index\search.html";i:1543588314;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>查询界面</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="shortcut icon" href="favicon.ico">
    <!-- <link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,900,700,900italic' rel='stylesheet' type='text/css'> -->

    <!-- Stylesheets -->
    <!-- Dropdown Menu -->
    <link rel="stylesheet" href="../static/css/superfish.css">
    <!-- Owl Slider -->
    <!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
    <!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
    <!-- Date Picker -->
    <link rel="stylesheet" href="../static/css/bootstrap-datepicker.min.css">
    <!-- CS Select -->
    <link rel="stylesheet" href="../static/css/cs-select.css">
    <link rel="stylesheet" href="../static/css/cs-skin-border.css">

    <!-- Themify Icons -->
    <link rel="stylesheet" href="../static/css/themify-icons.css">
    <!-- Flat Icon -->
    <link rel="stylesheet" href="../static/css/flaticon.css">
    <!-- Icomoon -->
    <link rel="stylesheet" href="../static/css/icomoon.css">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="../static/css/flexslider.css">

    <!-- Style -->
    <link rel="stylesheet" href="../static/css/style.css">

    <!-- Modernizr JS -->
    <script src="../static/js/modernizr-2.6.2.min.js"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <script src="../static/js/respond.min.js"></script>
    <![endif]-->

    <!--当前时间脚本-->
    <script type="text/javascript">
        Date.prototype.Format = function (fmt) { //author: meizz
            var o = {
                "M+": this.getMonth() + 1, //月份
                "d+": this.getDate(), //日
                "h+": this.getHours(), //小时
                "m+": this.getMinutes(), //分
                "s+": this.getSeconds(), //秒
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度
                "S": this.getMilliseconds() //毫秒
            };
            if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            return fmt;
        }
        var currentTime = new Date().Format("yyyy-MM-dd");

    </script>

    <!--选择入住和离店时间-->
    <script src="../static/js/laydate/laydate.js"></script>
    <script>
        var comeTime = leaveTime = currentTime;
        lay('#version').html('-v'+ laydate.v);
        //执行一个laydate实例
        laydate.render({
            elem: '#comeTimeSelecotor' //指定元素
            ,min: currentTime  //最小选择时间
            ,value: currentTime //初始值
            ,calendar: true
            ,done: function(value, date, endDate){
                //console.log(value); //得到日期生成的值，如：2017-08-18
                //console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                //console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                comeTime = value;
                console.log("选择入住时间：" + comeTime);
            }
        });

        laydate.render({
            elem: '#leaveTimeSelector' //指定元素
            ,calendar: true
            ,min: comeTime //初始值
            ,done: function(value, date, endDate){
                //console.log(value); //得到日期生成的值，如：2017-08-18
                //console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                //console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                leaveTime = value;
                console.log("选择离店时间：" + leaveTime);
            }
        });
    </script>


    <!--ajax交互-->
    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script>
        var searchResult = null;

        function ajaxPost(){
            var roomType = $("#room-type").val();
            var startTime = $("#comeTimeSelecotor").val();
            var endTime = $("#leaveTimeSelector").val();
            var guestNumber = $("#guest-number").val();
            $.ajax({
                type:"post",
                url:"<?php echo url('Index/index/anotherTest'); ?>",
                data:{
                    roomType:roomType,
                    startTime:startTime,
                    endTime:endTime,
                    guestNumber:guestNumber
                },
                success:function(data){
                    alert(JSON.stringify(data));
                    searchResult = JSON.stringify(data);
                }
            });
        }

    </script>

    <!--跳转到下单界面-->
    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script>
        function jumpTobook() {
            var myroomType = whatTypeRoom(getUrlParam('roomType'));
            var mystartTime = getUrlParam('startTime');
            var myendTime = getUrlParam('endTime');
            var myguestNumber = getUrlParam('guestNumber');
            var result = getUrlParam('result');
            var res2json = JSON.parse(result);
            var fitRoomId = res2json['fitSet'];

            var path = "<?php echo url('/book/index?roomType=" + myroomType + "&startTime=" + mystartTime
                + "&endTime=" + myendTime + "&guestNumber=" + myguestNumber + "&fitRoomId=" + fitRoomId +
                "&other=null"+  "'); ?>";
            document.location = path;
        }
    </script>
    
    <!--用于解析URL中的参数-->
    <script>
        function getUrlParam(paramName) {
            var paramValue = "", isFound = !1;
            if (this.location.search.indexOf("?") == 0 && this.location.search.indexOf("=") > 1) {
                arrSource = unescape(this.location.search).substring(1, this.location.search.length).split("&"), i = 0;
                while (i < arrSource.length && !isFound) arrSource[i].indexOf("=") > 0 && arrSource[i].split("=")[0].toLowerCase() == paramName.toLowerCase() && (paramValue = arrSource[i].split("=")[1], isFound = !0), i++
            }
            return paramValue == "" && (paramValue = null), paramValue
        }
    </script>

    <!--用于返回房间类型-->
    <script>
        function whatTypeRoom(roomname) {
            switch (roomname)
            {
                case 'stdsingle':
                    return 1;
                case 'stddouble':
                    return 2;
                case 'luxsingle':
                    return 3;
                case 'luxdouble':
                    return 4;
                case 'family':
                    return 5;
                default:
                    return -1;
            }

        }
    </script>

    <script>
        function roomTpye2roomName(myroomTpye)
        {
            switch (myroomTpye)
            {
                case "stdsingle":
                    return "标准大床房";
                case "stddouble":
                    return "标准双床房";
                case "luxsingle":
                    return "豪华大床房";
                case "luxdouble":
                    return "豪华双人房";
                case "family":
                    return "家庭亲子套房";
            }
        }
        function guestNumber2guestshow(guestNumber)
        {
            switch (guestNumber)
            {
                case "1a0c":
                    return "1成人";
                case "2a0c":
                    return "2成人";
                case "1a1c":
                    return "1成人 1儿童";
                case "2a01c":
                    return "2成人 1儿童";
            }

        }
    </script>

    <!-- Javascripts -->
    <script src="../static/js/jquery-2.1.4.min.js"></script>
    <!-- Dropdown Menu -->
    <script src="../static/js/hoverIntent.js"></script>
    <script src="../static/js/superfish.js"></script>
    <!-- Bootstrap -->
    <script src="../static/js/bootstrap.min.js"></script>
    <!-- Waypoints -->
    <script src="../static/js/jquery.waypoints.min.js"></script>
    <!-- Counters -->
    <script src="../static/js/jquery.countTo.js"></script>
    <!-- Stellar Parallax -->
    <script src="../static/js/jquery.stellar.min.js"></script>
    <!-- Owl Slider -->
    <!-- // <script src="js/owl.carousel.min.js"></script> -->
    <!-- Date Picker -->
    <script src="../static/js/bootstrap-datepicker.min.js"></script>
    <!-- CS Select -->
    <script src="../static/js/classie.js"></script>
    <script src="../static/js/selectFx.js"></script>
    <!-- Flexslider -->
    <script src="../static/js/jquery.flexslider-min.js"></script>

    <script src="../static/js/custom.js"></script>



</head>
<body>

<div id="fh5co-wrapper">
    <div id="fh5co-page">

        <!--右上角菜单栏-->
        <div id="fh5co-header">
            <header id="fh5co-header-section">
                <div class="container">
                    <div class="nav-header">
                        <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
                        <h1 id="fh5co-logo"><a href="index.html">X酒店信息管理系统</a></h1>
                        <nav id="fh5co-menu-wrap" role="navigation">
                            <ul class="sf-menu" id="fh5co-primary-menu">
                                <li><a class="active" href="index.html">主页</a></li>
                                <li>
                                    <a href="hotel.html" class="fh5co-sub-ddown">房型</a>
                                    <ul class="fh5co-sub-menu">
                                        <li><a href="#">标准大床房</a></li>
                                        <li><a href="#">标准双床房</a></li>
                                        <li><a href="#">豪华大床房</a></li>
                                        <li><a href="#">豪华双床房</a></li>
                                        <li><a href="#">家庭亲子套房</a></li>
                                        <li><a href="#">复式套房</a></li>
                                    </ul>
                                </li>
                                <li><a href="services.html">服务</a></li>
                                <li><a href="blog.html">图册</a></li>
                                <li><a href="contact.html">关于我们</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </header>

        </div>

        <!--顶部背景-->
        <div class="fh5co-parallax" style="background-image: url(../static/images/slider1.jpg);" data-stellar-background-ratio="0.5">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 text-center fh5co-table">
                        <div class="fh5co-intro fh5co-table-cell">
                            <h1 class="text-center">选择您喜欢的房间</h1>
                            <p>臻享尊贵 欢迎入住</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--查询框-->
        <div class="wrap">
            <div class="container">
                <div class="row">
                    <div id="availability">
                        <form action=#>
                            <div class="a-col">
                                <section>
                                    <select class="cs-select cs-skin-border" id="room-type">
                                        <option value="" disabled selected>选择房型</option>
                                        <option value="stdsingle">标准大床房</option>
                                        <option value="stddouble">标准双床房</option>
                                        <option value="luxsingle">豪华大床房</option>
                                        <option value="luxdouble">豪华双人房</option>
                                        <option value="family">家庭亲子套房 </option>
                                        <option value="loft">复式房</option>
                                    </select>
                                </section>
                            </div>
                            <div class="a-col alternate">
                                <div class="input-field">
                                    <label for="comeTimeSelecotor">入住时间</label>
                                    <input type="text" class="demo-input" placeholder="请选择日期" id="comeTimeSelecotor">
                                </div>
                            </div>
                            <div class="a-col alternate">
                                <div class="input-field">
                                    <label for="leaveTimeSelector">离开时间</label>
                                    <input type="text" class="demo-input" placeholder="" id="leaveTimeSelector" />
                                </div>
                            </div>

                            <div class="a-col">
                                <section>
                                    <div class="input-field">
                                        <select class="cs-select cs-skin-border" id="guest-number">
                                            <option value="" disabled selected>选择人数</option>
                                            <option value="1a0c">1成人</option>
                                            <option value="2a0c">2成人</option>
                                            <option value="1a1c">1成人 1儿童</option>
                                            <option value="2a1c">2成人 1儿童</option>
                                        </select>
                                    </div>
                                </section>
                            </div>

                            <div class="a-col action">
                                <a href="<?php echo url('/search/index'); ?>" onclick="ajaxPost()">
                                    <span> 立即查询</span>
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!--这里用来显示搜索后的内容-->
        <div id="fh5co-hotel-section">
            <div class="container" >
                <div class="row" id="mycontainer">
                    <h2 class="mb-5">已为您显示：
                        <script class="mb-5">
                            document.write('从： '+ getUrlParam('startTime')+ ' 到： ');
                            document.write(getUrlParam('endTime') + ' 的空闲 ');
                            document.write(roomTpye2roomName(getUrlParam('roomType')));

                            //document.write(' 可容纳：'+ guestNumber2guestshow(getUrlParam('guestNumber')));
                        </script>
                    </h2>
                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/stdsingle.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/night</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="<?php echo url('/book/index'); ?>"><i class="ti-calendar"></i>立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">标准大床房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/stddouble.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/晚</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="#"><i class="ti-calendar"></i> 立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">标准双床房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/luxsingle.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/晚</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="#"><i class="ti-calendar"></i> 立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">豪华大床房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/luxdouble.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/晚</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="#"><i class="ti-calendar"></i> 立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">豪华双床房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/family.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/晚</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="#"><i class="ti-calendar"></i> 立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">家庭亲子套房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                    <!--<div class="col-md-4">-->
                        <!--<div class="hotel-content">-->
                            <!--<div class="hotel-grid" style="background-image: url(../static/images/loft.jpg);">-->
                                <!--&lt;!&ndash;<div class="price"><small>价格</small><span>$100/晚</span></div>&ndash;&gt;-->
                                <!--<a class="book-now text-center" href="#"><i class="ti-calendar"></i> 立刻预订</a>-->
                            <!--</div>-->
                            <!--<div class="desc">-->
                                <!--<h3><a href="#">复式套房</a></h3>-->
                                <!--<p>价格：$100/天</p>-->
                                <!--<p>房型描述</p>-->
                            <!--</div>-->
                        <!--</div>-->
                    <!--</div>-->

                </div>
            </div>
        </div>


        <footer id="footer" class="fh5co-bg-color">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="copyright">
                            <p><small>&copy; 2018 数据库课设<p>  <br> All Rights Reserved. <br>by 陈楚鑫 李洋志 翁跃 谭钧升
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    </div>
    <!-- END fh5co-page -->

</div>
<!-- END fh5co-wrapper -->


<!--可用于动态加载div-->
<script type="text/javascript">
    var mycontainer = document.getElementById('mycontainer');
    console.log(mycontainer);
    var node = mycontainer.nextSibling;

    var result = getUrlParam('result');
    var resultJson = JSON.parse(result);
    var res = resultJson['res'];
    //alert(res);
    var roomType = whatTypeRoom(getUrlParam('roomType'));

    for(var i = 0;i<res;i++){
        //searchResult;
        dynamicShow(roomType);
    }


    function dynamicShow(roomtype){
        oDiv = document.createElement('div');
        switch (roomtype) {
            case 1:
                oDiv.innerHTML =
                    "<div class=\"col-md-4\">\n" +
                    "                        <div class=\"hotel-content\">\n" +
                    "                            <div class=\"hotel-grid\" style=\"background-image: url(../static/images/luxsingle.jpg);\">\n" +
                    "                                <!--<div class=\"price\"><small>价格</small><span>$100/晚</span></div>-->\n" +
                    "                                <a class=\"book-now text-center\" onclick=\"jumpTobook()\" \"><i class=\"ti-calendar\"></i> 立刻预订</a>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"desc\">\n" +
                    "                                <h3><a href=\"#\">" +
                    "                                标准大床房</a></h3>\n" +
                    "                                <p>价格：$100/天</p>\n" +
                    "                                <p>房型描述</p>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                    </div>";
                break;
            case 2:
                oDiv.innerHTML =
                    "<div class=\"col-md-4\">\n" +
                    "                        <div class=\"hotel-content\">\n" +
                    "                            <div class=\"hotel-grid\" style=\"background-image: url(../static/images/luxsingle.jpg);\">\n" +
                    "                                <!--<div class=\"price\"><small>价格</small><span>$100/晚</span></div>-->\n" +
                    "                                <a class=\"book-now text-center\" onclick=\"jumpTobook()\" \"><i class=\"ti-calendar\"></i> 立刻预订</a>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"desc\">\n" +
                    "                                <h3><a href=\"#\">" +
                    "                                标准双床房</a></h3>\n" +
                    "                                <p>价格：$200/天</p>\n" +
                    "                                <p>房型描述</p>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                    </div>";
                break;
            case 3:
                oDiv.innerHTML =
                    "<div class=\"col-md-4\">\n" +
                    "                        <div class=\"hotel-content\">\n" +
                    "                            <div class=\"hotel-grid\" style=\"background-image: url(../static/images/luxsingle.jpg);\">\n" +
                    "                                <!--<div class=\"price\"><small>价格</small><span>$100/晚</span></div>-->\n" +
                    "                                <a class=\"book-now text-center\" onclick=\"jumpTobook()\" \"><i class=\"ti-calendar\"></i> 立刻预订</a>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"desc\">\n" +
                    "                                <h3><a href=\"#\">" +
                    "                                豪华大床房</a></h3>\n" +
                    "                                <p>价格：$300/天</p>\n" +
                    "                                <p>房型描述</p>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                    </div>";
                break;
            case 4:
                oDiv.innerHTML =
                    "<div class=\"col-md-4\">\n" +
                    "                        <div class=\"hotel-content\">\n" +
                    "                            <div class=\"hotel-grid\" style=\"background-image: url(../static/images/luxsingle.jpg);\">\n" +
                    "                                <!--<div class=\"price\"><small>价格</small><span>$100/晚</span></div>-->\n" +
                    "                                <a class=\"book-now text-center\" onclick=\"jumpTobook()\" \"><i class=\"ti-calendar\"></i> 立刻预订</a>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"desc\">\n" +
                    "                                <h3><a href=\"#\">" +
                    "                                豪华双床房</a></h3>\n" +
                    "                                <p>价格：$400/天</p>\n" +
                    "                                <p>房型描述</p>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                    </div>";
                break;
            case 5:
                oDiv.innerHTML =
                    "<div class=\"col-md-4\">\n" +
                    "                        <div class=\"hotel-content\">\n" +
                    "                            <div class=\"hotel-grid\" style=\"background-image: url(../static/images/luxsingle.jpg);\">\n" +
                    "                                <!--<div class=\"price\"><small>价格</small><span>$100/晚</span></div>-->\n" +
                    "                                <a class=\"book-now text-center\" onclick=\"jumpTobook()\" \"><i class=\"ti-calendar\"></i> 立刻预订</a>\n" +
                    "                            </div>\n" +
                    "                            <div class=\"desc\">\n" +
                    "                                <h3><a href=\"#\">" +
                    "                                家庭亲子套房</a></h3>\n" +
                    "                                <p>价格：$500/天</p>\n" +
                    "                                <p>房型描述</p>\n" +
                    "                            </div>\n" +
                    "                        </div>\n" +
                    "                    </div>";
                break;

        }

        mycontainer.parentNode.insertBefore(oDiv, node);
        node = oDiv.nextSibling;
    }


</script>

</body>
</html>