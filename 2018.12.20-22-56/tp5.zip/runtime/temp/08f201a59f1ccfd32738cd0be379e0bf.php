<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"G:\phpStudy\PHPTutorial\WWW\tp5\public/../application/book\view\index\book.html";i:1545472235;}*/ ?>
<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <title>预定界面</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900|Rubik:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="../static/css/bootstrap.css">
    <link rel="stylesheet" href="../static/css/animate.css">
    <link rel="stylesheet" href="../static/css/owl.carousel.min.css">

    <link rel="stylesheet" href="../static/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="../static/fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../static/css/magnific-popup.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css">

    <!-- Theme Style -->
    <link rel="stylesheet" href="../static/css/style.css">

    <!--用于解析URL中的参数-->
    <script>
        function getUrlParam(paramName) {
            var paramValue = "", isFound = !1;
            if (this.location.search.indexOf("?") == 0 && this.location.search.indexOf("=") > 1) {
                arrSource = unescape(this.location.search).substring(1, this.location.search.length).split("&"), i = 0;
                while (i < arrSource.length && !isFound) arrSource[i].indexOf("=") > 0 && arrSource[i].split("=")[0].toLowerCase() == paramName.toLowerCase() && (paramValue = arrSource[i].split("=")[1], isFound = !0), i++
            }
            return paramValue == "" && (paramValue = null), paramValue
        }
    </script>

    <!--ajax交互 用于确认订单-->
    <script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
    <script>
        function Confirm_Order(){

            var totmoney = $("#totmoney").val();
            var arrival_date = $("#arrival_date").val();
            var leave_date = $("#leave_date").val();
            var room_type = $("#room_type").val();
            var guest_number = $("#guest_number").val();
            var guest_name = $("#guest_name").val();
            var guest_sex = $("#guest_sex").val();
            var card_type = $("#card_type").val();
            var guest_telephone = $("#guest_telephone").val();
            //var ID_number = $("#ID_number").val();
            var ID_number = getId('card_id');
            var message = $("#message").val();
            var fitRoomId = getUrlParam('fitRoomId');
            //alert(fitRoomId);

            //alert(arrival_date+" "+leave_date+" "+room_type+ " ");

            $.ajax({
                type:"post",
                url:"<?php echo url('Book/index/doBook'); ?>",
                data:{
                    totmoney:totmoney,
                    arrival_date:arrival_date,
                    leave_date:leave_date,
                    room_type:room_type,
                    guest_number:guest_number,
                    guest_name:guest_name,
                    guest_sex:guest_sex,
                    card_type:card_type,
                    ID_number:ID_number,
                    guest_telephone:guest_telephone,
                    message:message,
                    fitRoomId:fitRoomId
                }
            });
            var path = "<?php echo url('/thanks/index?totmoney=" + totmoney + "&arrival_date=" + arrival_date
                 + "&leave_date="+leave_date + "&room_type="+room_type + "&guest_number="+guest_number
                + "&guest_name="+guest_name + "&guest_sex="+guest_sex + "&card_type="+card_type + "&ID_number="+ID_number
                + "&guest_telephone="+guest_telephone + "&message="+message +  "&other=null"+  "'); ?>";
                //alert(path);
            document.location = path;
        }

    </script>

    <!--将URL中的参数写入表单-->
    <script>

        function guestTpye2guestNumber(guestTpye)
        {
            switch (guestTpye)
            {
                case '1a0c':
                    return 0;
                case '2a0c':
                    return 1;
                case '1a1c':
                    return 2;
                case '2a1c':
                    return 3;
            }
        }



        function writeValue()
        {
            var roomType = getUrlParam('roomType');
            var arrivalDay = getUrlParam('startTime');
            var leaveDay = getUrlParam('endTime');
            var guestNumber = getUrlParam('guestNumber');


            document.getElementById('arrival_date').value = arrivalDay;
            document.getElementById('leave_date').value = leaveDay;
            document.getElementById('totmoney').value = roomType*100;

            var select = document.getElementById('room_type');
            select.options[roomType-1].selected = true;

            select = document.getElementById('guest_number');
            var index = guestTpye2guestNumber(guestNumber);
            //alert(index);
            select.options[index].selected = true;

            //document.getElementById().value = roomType;
            //document.getElementById('guest_number').value = guestNumber;
        }
    </script>

</head>
<body onload="writeValue()">

</br>
</br>
</br>

<section class="site-section">
    <div class="container">
        <h1 class="mb-5">请确认您的订单</h1>
        <div class="row">
            <div class="col-md-6">
                <h2 class="mb-5">房间信息</h2>
                <form  method="post">

                    <div class="row">
                        <div class="col-sm-6 form-group">
                            <label>到达日期</label>
                            <div style="position: relative;">
                               <input type='text' class="form-control" id='arrival_date' />
                            </div>
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="">离店日期</label>
                            <div style="position: relative;">
                                <input type='text' class="form-control" id='leave_date' />
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6 form-group">
                            <label>房间类型</label>
                            <select style="position: relative;width:245px; height: 50px" name="" id='room_type'>
                                <option value="stdsingle">标准大床房</option>
                                <option value="stddouble">标准双床房</option>
                                <option value="luxsingle">豪华大床房</option>
                                <option value="luxdouble">豪华双人房</option>
                                <option value="family">家庭亲子套房 </option>
                            </select>
                        </div>


                        <div class="col-sm-6 form-group">
                            <label for="">人数</label>
                            <select style="position: relative;width:245px; height: 50px" name="" id="guest_number">
                                <option value="1a0c">1成人</option>
                                <option value="2a0c">2成人</option>
                                <option value="1a1c">1成人 1儿童</option>
                                <option value="2a1c">2成人 1儿童</option>
                            </select>
                        </div>


                        <div class="col-sm-6 form-group">
                            <label >总价</label>
                            <div style="position: relative;">
                                <input disabled="disabled" type='text' class="form-control" id='totmoney' />
                            </div>
                        </div>
                    </div>




                    <h2 class="mb-5">客人信息</h2>

                    <div class="row">
                        <div class="col-sm-6 form-group">
                            <label for="">姓名*</label>
                            <div style="position: relative;">
                                <input type='text' class="form-control" id='guest_name' />
                            </div>
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="guest_sex">性别*</label>
                            <select style="position: relative;width:245px; height: 50px" name="" id="guest_sex">
                                <option value="women">女</option>
                                <option selected="selected" value="man">男</option>
                            </select>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="card_type">证件类型*</label>
                            <select style="position: relative;width:245px; height: 50px" name="" id="card_type">
                                <option value="0" selected="selected" >居民身份证</option>
                                <option value="1">护照</option>
                                <option value="2">港澳台通行证</option>
                                <option value="3">兵役证</option>
                            </select>
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="">证件号码*</label>
                            <div style="position: relative;">
                                <input type='text' class="form-control" id='ID_number' />
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6 form-group">
                            <label for="">联系方式*</label>
                            <div style="position: relative;">
                                <input type='text' class="form-control" id='guest_telephone' />
                            </div>
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="">电子邮箱</label>
                            <div style="position: relative;">
                                <input type='text' class="form-control" id='guest_email' />
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label>备注信息</label>
                            <textarea name="message" id="message" class="form-control " cols="30" rows="8"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group" >
                            <input type="button" value="确认订单" class="btn btn-primary" onclick="Confirm_Order()">
                        </div>
                    </div>
                </form>
            </div>


            <div class="col-md-5">
                <h3 class="mb-5">房型介绍</h3>
                <div class="media d-block room mb-0">
                    <figure>
                        <img src="../static/images/img_1.jpg" alt="Generic placeholder image" class="img-fluid">
                        <div class="overlap-text">
                  <span>
                    好评指数
                    <span class="ion-ios-star"></span>
                    <span class="ion-ios-star"></span>
                    <span class="ion-ios-star"></span>
                    <span class="ion-ios-star"></span>
                    <span class="ion-ios-star"></span>
                  </span>
                        </div>
                    </figure>
                    <div class="media-body">
                        <h3 class="mt-0"><a href="#">房间名称</a></h3>
                        <ul class="room-specs">
                            <li><span class="ion-ios-people-outline"></span> 2位客人 </li>
                            <li><span class="ion-ios-crop"></span> 22 平方米</li>
                        </ul>
                        <p>极致的体验</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END section -->

<!--底部-->
<footer class="site-footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 text-center">
                &copy;
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved

            </div>
        </div>
    </div>
</footer>
<!-- END footer -->

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

<script src="../static/js/jquery-3.2.1.min.js"></script>
<script src="../static/js/jquery-migrate-3.0.0.js"></script>
<script src="../static/js/popper.min.js"></script>
<script src="../static/js/bootstrap.min.js"></script>
<script src="../static/js/owl.carousel.min.js"></script>
<script src="../static/js/jquery.waypoints.min.js"></script>
<script src="../static/js/jquery.stellar.min.js"></script>

<script src="../static/js/jquery.magnific-popup.min.js"></script>
<script src="../static/js/magnific-popup-options.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>

<script>

    $('#arrival_date, #leave_date').datepicker({});

</script>

<script>
	if (getCookie('loginstatus')) {
		var customer_id = getId('card_id');
		//var join_time=CURRENT_TIMESTAMP;
		$.ajax({
			type: "post",
			url: "<?php echo url('Book/Index/findName'); ?>",
			data: {
				customer_id: customer_id
				//join_time: join_time
			},
			success: function(data) {
				searchResult = JSON.stringify(data);
				res2json=JSON.parse(searchResult);
				res=res2json['doRes'];
				bigres=res[0].customer_name;
				if(null != res && "" != res){
					document.getElementById('guest_name').value = bigres;
					//填写
				}
			}
		});
}
function getCookie() {
    var arr1 = document.cookie.split(';');
    for (var i = 0; i < arr1.length; i++) {
        var arr2 = arr1[i].split('=');
        if (arr2[1] == '1') {
            return arr2[1];
        }
    }
}
function getId(key) {
    var arr1 = document.cookie.split(';');
    for (var i = 0; i < arr1.length; i++) {
        var arr2 = arr1[i].split('=');
        if (arr2[0] == key) {
            return arr2[1];
        }
    }
}
	
</script>

<script src="../static/js/main.js"></script>
</body>
</html>