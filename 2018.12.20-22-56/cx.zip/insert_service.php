<!DOCTYPE html>
<html>
<body>
<?php
	$con =mysql_connect("localhost","root","root");
	if (!$con){
	  die('Could not connect: ' . mysql_error());
	}else{
	}
	mysql_select_db("hotel", $con);
	$result = mysql_query("
		Select service_name,service_id,remark,price
		from service
		order by service_id
	");
	while($row=mysql_fetch_array($result)){
		//echo $row["service_id"];
		if($_GET[$row["service_id"]]!="0"){
			$insert_result=mysql_query("
				insert into serviceorder(transaction_id,count,service_id,is_finish) values(
					".$_GET["order_id"].",".$_GET[$row["service_id"]].",".$row["service_id"].",1
				)
			");
			if($insert_result==false){
				echo "myg";
			}
		}
		
	}
?>
</body>
</html>