12/21晚，cx文件夹更新，数据库改动，
添加了两个视图，和一个触发器，
改动serviceorder和service表

答辩之前跑一下sql
