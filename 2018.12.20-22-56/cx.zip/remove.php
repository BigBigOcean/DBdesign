
<?php
	$con = mysql_connect("localhost","root","root");
	if (!$con){
	  die('Could not connect: ' . mysql_error());
	}else{
	}
	mysql_select_db("hotel", $con);
	$result=mysql_query("
		select is_finish
		from serviceorder
		where serviceorder_id=".$_GET['id']."
	");
	if($result["is_finish"]==3||$result["is_finish"]==4){
		echo "很抱歉！该服务已经消费，不允许退款，请刷新！";
	}else{
		mysql_query("
		delete from serviceorder 
		where serviceorder_id=".$_GET['id']."
		");
		echo "服务退订成功！";
	}

?>