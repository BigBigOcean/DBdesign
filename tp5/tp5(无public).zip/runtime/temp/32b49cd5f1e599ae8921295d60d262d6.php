<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"G:\phpStudy\PHPTutorial\WWW\tp5\public/../application/index\view\logintest\index.html";i:1545805198;}*/ ?>
<!DOCTYPE HTML>
<html>
<head>
<title>登录页面</title>
<link href="../../static/css/logintest/style.css" rel="stylesheet" type="text/css" media="all" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<!-- -->
<script src="../../static/js/jquery.min.js"></script>

</head>
<body>
<!-- contact-form -->	
<div class="message warning">
<div class="inset">
	<div class="login-head">
		<h1>X酒店登录系统</h1>
	</div>
		<form>
			<li>
				<input id="user" type="text" class="text" value="您的证件号码" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '您的姓名';}">
			</li>
				<div class="clear"> </div>
			<li>
				<input id="password" type="password" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'password';}"> 
			</li>
			<div class="clear"> </div>
			<div class="submit">
				<input type="button" id="login" value="会员登录" >
				<input type="button" onclick="gotoAdmin()" id="mlogin" value="管理员登录" >
				<h4><a href="<?php echo url('Index/Regist/index'); ?>" id="regist">未有账号？马上注册！</a></h4>
<div class="clear">  </div>	
			</div>
				
		</form>
		</div>					
	</div>
	</div>
	<div class="clear"> </div>
<!--- footer --->
<!--<div class="footer">
	<p>&copy; 2018 数据库课设  <br> All Rights Reserved. <br>by 陈楚鑫 李洋志 翁跃 谭钧升</p>
</div>-->

</body>
</html>
<script src="//cdn.bootcss.com/jquery/3.1.1/jquery.min.js"></script>
<script>
	var searchResult = null;
	function ajaxPost() {
		var customer_name = $("#user").val();
		var password = $("#password").val();
		//var join_time=CURRENT_TIMESTAMP;
		$.ajax({
			type: "post",
			url: "<?php echo url('Search/index/doLogin'); ?>",
			data: {
				customer_name: customer_name,
				password: password
				//join_time: join_time
			},
			success: function(data) {
				searchResult = JSON.stringify(data);
				res2json=JSON.parse(searchResult);
				res=res2json['doRes'];
				if(null != res && "" != res){
					alert("登陆成功！");
					loginJudge('1');
				}else{
					alert("用户不存在或密码错误！");
					loginJudge('0');
				}
			}
		});
	}
</script>
<script type="text/javascript">
	var login = document.querySelector('#login');
	var user = document.querySelector('#user')	;
	var hist=-1;
	regist.onclick = function(){
		hist=-2;
	}
	login.onclick = function(){
		ajaxPost();
//		alert(document.cookie);
	}
	function loginJudge(ping){
		if(ping=='1'){
			setCookie('card_id',user.value,5);
			setCookie('loginstatus','1',5);
//			window.history.go(hist);
			window.location.href='http://localhost:81/tp5/public/';
		}else{
			$("#user").val="";
			$("#password").val="";
		}
	}
	function getCookie(key){
		var arr1 = document.cookie.split(';');
			for(var i = 0;i< arr1.length;i++){
				var arr2 = arr1[i].split('=');
				if(arr2[0] == key){
					return arr2[1];
				}
		}
	}
	function setCookie(c_name,value,expiredays)
	{
		var exdate=new Date();
		exdate.setDate(exdate.getDate()+expiredays);
		document.cookie=c_name+ "=" +escape(value)+
		((expiredays==null) ? "" : ";expires="+exdate.toGMTString()+";path=/");
	}
	function gotoAdmin(){
		if(document.querySelector('#user').value=="admin"&&document.querySelector('#password').value){
				window.location.href="../../../../dbfinal/test.php";
			}else{
				alert("管理员账号密码错误！");
			}
	}
</script>