<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>

<div class="container event-wrapper">

    <?php
    /*echo '<form id="form1" name="form1" method="post" action="op_job.php">
      <input type="hidden" name="op"  value="5"/>
    </form>';
    echo '<script   language="javascript">
      document.form1.submit();
      </script>';
    */
    //先查询所有的职位
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_job.php">
  <input type="hidden" name="op"  value="2"/>
</form>
    <script   language="javascript">
        document.form.submit()
  </script>
    ';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 2:
                {
//                var_dump($_POST["select_job_name"]);
                    $select_job_id = explode(",", $_POST["select_job_id"]);
//                var_dump($select_job_id);
                    $select_job_name = explode(",", $_POST["select_job_name"]);
//                var_dump($select_job_name);
                    $select_salary = explode(",", $_POST["select_salary"]);
//                var_dump($select_salary);
                    $count_job = count($select_job_id);
//                $selec_job = array_combine($select_job_id, $select_job_name);
//                var_dump($selec_job);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>

    <a href="ManageStuff.php"><input type="button" value="返回上一页"> </a>
    <form action="search.php" method="post">
        <table>
            <tr>
                <hr/>
                查询职位信息
            </tr>
            <tr>
                <th>职位名字</th>

            </tr>
            <th><input type="text" name="search_job_name" value="cleaner"></th>
        </table>
        <input type="hidden" name="op_search" value="1">
        <input id="test" type="submit" value="查询">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr/>
                新增职位
            </tr>
            <tr>
                <th>职位</th>
                <th>月薪</th>
            </tr>

            <th><input type="text" name="job_name" value="job1"></th>
            <th><input type="text" name="salary" value="10000"</th>
        </table>
        <input type="hidden" name="op" value="1">
        <input type="submit" value="增加新职位">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr/>
                编辑职位信息
            </tr>
            <th>
                <select name="edit_job">
                    <?php //循环显示职位，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_job; $i++) {
                        echo "<option value=" . $select_job_id[$i] . ">" . $select_job_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
            <th>
                <input type="text" name="edit_salary" value="500">
            </th>
        </table>
        <input type="hidden" name="op" value="3">
        <input type="submit" value="提交修改">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr/>
                删除职位
            </tr>
            <th>
                <select name="delete_job_name">
                    <?php //循环显示职位，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_job; $i++) {
                        echo "<option value=" . $select_job_id[$i] . ">" . $select_job_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="4">
        <input type="submit" value="删除">
    </form>


    <div class="signup-form">
        <table>
            <tr>
                <hr/>
                职位信息
            </tr>
            <tr>
                <th>职位</th>
                <th>月薪</th>
            </tr>
            <?php
            for ($i = 0; $i < $count_job; $i++) {
                echo "<tr>";
                echo "<th>" . $select_job_name[$i] . "</th>";
                echo "<th>" . $select_salary[$i] . "</th>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</div>


</html>