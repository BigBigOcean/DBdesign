<?php
namespace app\index\controller;
use think\Controller;
use think\Db;

class Regist extends Controller{
 
    public function index (){
  
    	return $this->fetch();
    }
    
}

?>