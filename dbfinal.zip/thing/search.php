<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/27
 * Time: 15:06
 */
include("../conn.php");
if ($_POST) {
    $op = $_POST["op_search"];
    switch ($op) {
        case 1://在editType里面查询员工信息
            {
                //首选获得所有的物品信息
                $query_thing = "SELECT thing_id,thing_name FROM originalthing ORDER BY thing_id DESC";
                $tmp_thing = mysqli_query($link, $query_thing);
                $result = mysqli_fetch_array($tmp_thing);
                $thing_id = array($result["thing_id"]);
                $thing_name = array($result["thing_name"]);
                while ($row = mysqli_fetch_array($tmp_thing)) {
                    $thing_id = array_merge(array($row["thing_id"]), $thing_id);
                    $thing_name = array_merge(array($row["thing_name"]), $thing_name);
                }
                $thing_key_id = array_combine($thing_id, $thing_name);
                $thing_key_name = array_combine($thing_name, $thing_id);
//                var_dump($thing);

                $search_thing_type = $_POST["search_thing_type"];
                $search_thing = $_POST["search_thing"];
                if ($search_thing_type == 1) {
                    $query_search_thing = "SELECT * FROM originalthing WHERE thing_id='$search_thing'";

                }
                if ($search_thing_type == 2) {
                    $query_search_thing = "SELECT * FROM originalthing WHERE thing_name LIKE '$search_thing' ORDER BY thing_id ASC";

                }
                $tmp_search_thing = mysqli_query($link, $query_search_thing);
//                $result_thing=mysqli_fetch_array($tmp_search_thing);
//                var_dump($result_thing["thing_name"]);
                echo "<table>
        <tr>
        <th>物品ID</th>
        <th>物品名</th>
        <th>最大数量</th>
        <th>仓库位置</th>
        <th>联系电话</th>
        <th>备注</th>
        </tr>";
//                for($i=1;$i<=count())
                while ($row = mysqli_fetch_array($tmp_search_thing)) {
//                    var_dump($row);
                    echo "<tr>";
                    echo "<th>" . $row['thing_id'] . "</th>";
                    echo "<th>" . $row['thing_name'] . "</th>";
                    echo "<th>" . $row['thing_num'] . "</th>";
                    echo "<th>" . $row['position'] . "</th>";
                    echo "<th>" . $row['repairphone'] . "</th>";
                    echo "<th>" . $row['remark'] . "</th>";
                    echo "</tr>";
                }
                echo "</table>";

                echo "<a href='EditType.php'><input type='button' value='返回上一页'></a>";
                break;
            }
        case 26://在editType里面查询所有的物品类型
            {

                $search_thing_name = $_POST["search_thing_name"];
                $query_search_thing_name = "SELECT salary FROM thing WHERE thing_name='$search_thing_name'";
                $tmp_salary = mysqli_query($link, $query_search_thing_name);
                $row = mysqli_fetch_array($tmp_salary);
//               var_dump( $row["salary"]);
                $search_salary = $row["salary"];
                echo "
                        <table>
                        <tr>
                        <th>职位</th>
                        <th>工资</th>
                        //</tr>//
                        <tr>
                        <th> $search_thing_name</th>
                        <th> $search_salary </th>
</tr>
                        </table>";
                echo "<a href='Editthing.php'><input type='button' value='返回上一页'></a>";
                break;
            }
        case 27://从editthing里面查询所有的某房间的物品
            {
                echo '<a href="EditThing.php"><input type="button" value="返回上一页"></a>';


//先找到所有的物品类型
                $query_select_originalthing = "SELECT * FROM originalthing ORDER BY thing_id ASC";
                $select_originalthing = mysqli_query($link, $query_select_originalthing);
//                var_dump($select_thing);
                $result = mysqli_fetch_array($select_originalthing);
                $result_thing_id = array($result["thing_id"]);
                $result_thing_name = array($result["thing_name"]);

                while ($row = mysqli_fetch_array($select_originalthing)) {
                    $row_thing_id = array($row["thing_id"]);
                    $row_thing_name = array($row["thing_name"]);

                    $result_thing_id = array_merge($result_thing_id, $row_thing_id);
                    $result_thing_name = array_merge($result_thing_name, $row_thing_name);
                }
                $originalthing = array_combine($result_thing_id, $result_thing_name);
                $count_thing=count($result_thing_id);

                $search_room_id = $_POST["search_room_id"];

                //增加新物品
                echo "<hr/>
                            <form action=\"op_thing.php\" method=\"post\">
                                <table>
                                    <tr>
                                        <hr/>
                                        添加新物品：
                                    </tr>
                                    <tr>
                                        <th>
                                            物品
                                        </th>
                                        <th>
                                            物品状态
                                        </th>
                                    </tr>
                                    <tr> 
                                        <th>
                                            <select name='thing_id'>";

                                                for ($i = 0; $i < $count_thing; $i++) {
                                                    echo "<option value=" . $result_thing_id [$i] . ">" . $result_thing_name[$i] . "</option>";
                                                }

                                  echo "</select>
                                        </th>
                                        <th>
                                            <input type='text' name='thing_status' value='1'>
                                        </th>
                                    </tr>
                                </table>
                                <input type='hidden' name='room_id' value=".$search_room_id.">
                                <input type='hidden' name='op' value='29'>
                                <input type='submit' value='增加'>
                            </form>
                         ";

                //显示出一个房间拥有的所有物品
                $query_search_things_in_room = "SELECT * FROM thing WHERE room_id='$search_room_id' ORDER BY thing_id ASC";
                $tmp_things = mysqli_query($link, $query_search_things_in_room);
                echo "<p><hr/>查询结果</p>";
                echo "<table>
                        <tr>
                        <th>房号</th>
                        <th>物品ID</th>
                        <th>物品名字</th>
                        <th>物品状态</th>
                        </tr>";

                while ($row = mysqli_fetch_array($tmp_things)) {
                    echo "<tr>";
                    echo "<th>" . $search_room_id . "</th>";
                    echo "<th>" . $row['thing_id'] . "</th>";
                    echo "<th>" . $originalthing[$row['thing_id']] . "</th>";
//                    echo "<th>" . $row['thing_status'] . "</th>";
                    //编辑一个房间的物品状态
                    echo "<form action='op_thing.php'  method='post'>
                                   
                                
                                 <th>
                                    <input type='text' name='thing_status' value='" . $row['thing_status'] . "'
                                 </th>
                                 <th>
                                    <input type='hidden' name='op' value='27'>
                                    <input type='hidden' name='thing_id' value='" . $row['thing_id'] . "'>
                                    <input type='hidden' name='room_id' value='" . $search_room_id . "'>
                                    <input type='submit' value='编辑'>
                                 </th>
                                 
                            </form>";
                    echo "
                                
                                <form action='op_thing.php' method='post'>
                                    <th>
                                    
                                        <input type='hidden' name='delete_thing_id' value='" . $row['thing_id'] . "'>
                                        <input type='hidden' name='delete_room_id' value='" . $search_room_id . "'>
                                        <input type='hidden' name='op' value='28'>
                                        <input type='submit' value='删除'>
                                    </th>
                                </form>
                                
                        ";
                    echo "</tr>";
                }
                echo "</table>";
                break;
            }
        default:
            {
                break;
            }
    }
}
?>