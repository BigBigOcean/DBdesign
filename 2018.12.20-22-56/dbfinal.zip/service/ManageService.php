<?php
header("location:EditService.php");
?>