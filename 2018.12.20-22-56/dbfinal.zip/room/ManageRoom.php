﻿<html>
<head>
    <link rel="stylesheet" type="text/css" href="../home/css/nav.css" />
    <meta content="text/html; charset=utf-8" />
</head>
<body class="center-in-center">
<ul>
    <li><a href="EditType.php">管理房型</a></li>
    <li><a href="EditRoom.php">管理房间</a></li>
</ul>
<a href="../test.php">返回上一页</a>
</body>

</html>