<?php
namespace app\search\controller;
use think\Controller;
use think\Db;
use think\response\Json;

class Index extends Controller
{
    public function index()
    {
        return view('search');
    }

    public function whatTypeId($roomType)
    {
        switch ($roomType)
        {
            case 'stdsingle':
                return 1;
            case 'stddouble':
                return 2;
            case 'luxsingle':
                return 3;
            case 'luxdouble':
                return 4;
            case 'family':
                return 5;
            default:
                return -1;
        }
    }

    public function chooseRoom($roomType, $confict)
    {
        $confictSet = array();
        for($i=0; $i<sizeof($confict); $i++)
        {
            array_push($confictSet, $confict[$i]['room_id']);
        }

        $totSet = array();
        $max = ($roomType == 5 ? 45 : $roomType*10);
        for($i = ($roomType-1)*10 + 1; $i<=$max; $i++)
        {
            array_push($totSet, $i);
        }

        return $fitSet = array_diff($totSet, $confictSet);

    }

    public function doSearch($roomType,$startTime, $endTime, $guestNumber)
    {
        $db = Db::name('hotel');
        $res1 = $db->query('SELECT transaction_id from transaction WHERE reserve_time > ? or leave_time < ?',[$endTime, $startTime]);
        $NotConfictSet = array();   //不冲突的tran_id集合
        for($i=0; $i<sizeof($res1); $i++)
        {
            array_push($NotConfictSet, $res1[$i]['transaction_id']);
        }

        //判断roomtype
        $roomType_id = $this->whatTypeId($roomType);

        //冲突集合
        $ConfictSet = Db::table('table_order')
            ->field('room_id')
            ->where('roomType_id','eq',$roomType_id)
            ->where('transaction_id','not in',$NotConfictSet)
            ->select();

        $useNumber = sizeof($ConfictSet);   //使用了的房间数
        $totNumber = Db::table('roomtype')
            ->field('maxnum')
            ->where('roomType_id','eq',$roomType_id)
            ->select();

        $totNumber = $totNumber[0]['maxnum'];

        $restNumebr = $totNumber - $useNumber;

        $fitset = $this->chooseRoom($roomType_id, $ConfictSet);

        return ['res'=>$restNumebr, 'fitSet'=>$fitset[1]];
        //return ['NotConfict'=>$NotConfictSet, 'confictSet'=> $ConfictSet, 'totNumber'=>$totNumber, 'useNumber'=>$useNumber, 'res'=>$restNumebr, 'fitSet'=>$fitset];


        //return ['NotConfict'=>$NotConfictSet, 'confictSet'=> $ConfictSet, 'totNumber'=>$totNumber, 'useNumber'=>$useNumber, 'restNumebr'=>$restNumebr, 'fitSet'=>$fitSet];
        //return ['startTime'=>$startTime, 'endTime'=>$endTime,'confictSet'=> $ConfictSet, 'res'=>$res, 'fitSet'=>$fitSet];


    }
    public function doRegist($customer_name, $sex, $password1, $card_id, $card_type )
    {
        //$db = Db::name('hotel');
        //return (['type'=>$roomType, 'time1'=>$startTime, 'time2'=>$endTime, 'guestNumber'=>$guestNumber]);
        //$doResult = $db->query('INSERT INTO `hotel`.`customer` (`card_id`,
         //`password`, `card_type`, `customer_name`, `sex`, `join_time`) 
         //VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)',[$card_id, $password, $card_type, $customer_name, $sex]);
        //return $tranSet[0]['transaction_id'];
        $data2consume = ['card_id'=>$card_id, 'password'=>$password1, 'card_type'=>$card_type, 'customer_name'=>$customer_name, 'sex'=>$sex,'join_time'=>'2018-11-11'];
        $doResult = Db::table('customer')->insert($data2consume);
        return ['doRes'=> $doResult];

    }
    public function doLogin($customer_name, $password)
    {
        $db = Db::name('hotel');       
        $tranSet = $db->query('select card_id from customer where card_id = ?  and password = ? ',[$customer_name, $password]);
       
        return ['doRes'=> $tranSet];

    }

}