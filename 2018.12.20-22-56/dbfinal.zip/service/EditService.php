<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>

<div class="container event-wrapper">

    <?php
    /*echo '<form id="form1" name="form1" method="post" action="op_service.php">
      <input type="hidden" name="op"  value="5"/>
    </form>';
    echo '<script   language="javascript">
      document.form1.submit();
      </script>';
    */
    //先查询所有的服务
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_service.php">
  <input type="hidden" name="op"  value="2"/>
</form>
    <script   language="javascript">
        document.form.submit()
  </script>
    ';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 2:
                {

                    $select_service_id = explode(",", $_POST["select_service_id"]);
                    $select_service_name = explode(",", $_POST["select_service_name"]);
                    $select_price = explode(",", $_POST["select_price"]);
                    $select_remark = explode(",", $_POST["select_remark"]);
                    $count_service = count($select_service_id);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>

    <a href="../test.php"><input type="button" value="返回上一页"> </a>

    <form action="op_service.php" method="post">
        <table>
            <tr>
                <hr/>
                新增服务
            </tr>
            <tr>
                <th>服务名</th>
                <th>价格</th>
                <th>备注</th>
            </tr>

            <th><input type="text" name="service_name" value="service1"></th>
            <th><input type="text" name="price" value="100"</th>
            <th><input type="text" name="remark"></th>
        </table>
        <input type="hidden" name="op" value="1">
        <input type="submit" value="增加新服务">
    </form>

    <form action="op_service.php" method="post">
        <table>
            <tr>
                <hr/>
                修改服务信息
            </tr>
            <tr>
                <th>服务</th>
                <th>价格</th>
                <th>备注</th>
            </tr>
            <th>
                <select name="edit_service">
                    <?php //循环显示服务，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_service; $i++) {
                        echo "<option value=" . $select_service_id[$i] . ">" . $select_service_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
            <th>
                <input type="text" name="edit_price" value="500">
            </th>
            <th>
                <input type="text" name="edit_remark">
            </th>
        </table>
        <input type="hidden" name="op" value="3">
        <input type="submit" value="提交修改">
    </form>

    <form action="op_service.php" method="post">
        <table>
            <tr>
                <hr/>
                删除服务
            </tr>
            <th>
                <select name="delete_service_name">
                    <?php //循环显示服务，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_service; $i++) {
                        echo "<option value=" . $select_service_id[$i] . ">" . $select_service_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="4">
        <input type="submit" value="删除">
    </form>


    <table>
        <tr>
            <hr/>
            服务信息
        </tr>
        <tr>
            <th>服务ID</th>
            <th>服务名</th>
            <th>价格</th>
            <th>备注</th>
        </tr>
        <?php
        for ($i = 0; $i < $count_service; $i++) {
            echo "<tr>";
            echo "<th>" . $select_service_id[$i] . "</th>";
            echo "<th>" . $select_service_name[$i] . "</th>";
            echo "<th>" . $select_price[$i] . "</th>";
            echo "<th>" . $select_remark[$i] . "</th>";
            echo "</tr>";
        }
        ?>
    </table>
</div>


</html>