<?php
/**
 * Created by PhpStorm.
 * User: 56989
 * Date: 2018/11/30
 * Time: 23:34
 */

namespace app\thanks\controller;
use think\Controller;

class Index
{
    public function index()
    {
        return view('thanks');
    }
}