<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>
<div class="container event-wrapper">
    <?php
    //edittype所有操作op从1到25

    //先查询所有的物品种类
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_thing.php">
    <input type="hidden" name="op"  value="50"/>
</form>
<script   language="javascript">
    document.form.submit()
</script>
';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 50:
                {
//                var_dump($_POST["select_thing_name"]);
                    $select_thing_id = explode(",", $_POST["select_thing_id"]);
//                var_dump($select_thing_id);
                    $select_thing_name = explode(",", $_POST["select_thing_name"]);
//                var_dump($select_thing_name);
                    $select_thing_num = explode(",", $_POST["select_thing_num"]);
                    $select_position = explode(",", $_POST["select_position"]);
                    $select_repairphone = explode(",", $_POST["select_repairphone"]);
                    $select_remark = explode(",", $_POST["select_remark"]);
//                var_dump($select_salary);
                    $count_thing = count($select_thing_id);
//                $selec_thing = array_combine($select_thing_id, $select_thing_name);
//                var_dump($selec_thing);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>
    <a href="ManageThing.php"><input type="button" value="返回上一页"></a>

    <form action="search.php" method="post">
        <table>
            <tr>
                <hr/>
                查询
            </tr>
            <tr>
                <th>
                    <select name="search_thing_type">
                        <option value="1">按ID搜索</option>
                        <option value="2">按名字搜索</option>
                    </select>
                </th>
                <th>
                    <input type="text" name="search_thing" value="1">
                </th>

            </tr>
        </table>
        <input type="hidden" name="op_search" value="1">
        <input type="submit" value="查询">
    </form>

    <p>增加一个新物品类型：<br/></p>
    <form action="op_thing.php" method="post">
        <table>
            <tr>
                <th>物品名字</th>
                <th>物品最大数量</th>
                <th>物品存放位置</th>
                <th>联系电话</th>
                <th>备注</th>
            </tr>
            <tr>
                <td><input type="text" name="thing_name" value="test"></td>
                <td><input type="text" name="thing_num" value="5"></td>
                <td><input type="text" name="position" value="3"></td>
                <td><input type="text" name="repairphone" value="133"></td>
                <td><input type="text" name="remark"></td>
            </tr>
        </table>
        <br/>
        <input type="hidden" name='op' value="1">
        <input type="submit" value="提交">
    </form>

    <form action="op_thing.php" method="post">
        <table>
            <tr>
                <hr/>
                删除物品
            </tr>
            <th>
                <select name="delete_thing_name">
                    <?php //循环显示物品，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_thing; $i++) {
                        echo "<option value=" . $select_thing_id[$i] . ">" . $select_thing_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="2">
        <input type="submit" value="删除">
    </form>
    <div class="signup-form">
        <table >
            <tr>
                <hr/>
                物品信息
            </tr>
            <tr>
                <th class="student-id">物品ID</th>
                <th>物品名</th>
                <th>最大数量</th>
                <th>仓库位置</th>
                <th>联系电话</th>
                <th>备注</th>
            </tr>
            <?php
            for ($i = 0; $i < $count_thing; $i++) {
                echo "<tr>";
                echo "<th>" . $select_thing_id[$i] . "</th>";
                echo "<th>" . $select_thing_name[$i] . "</th>";
                echo "<th>" . $select_thing_num[$i] . "</th>";
                echo "<th>" . $select_position[$i] . "</th>";
                echo "<th>" . $select_repairphone[$i] . "</th>";
                echo "<th>" . $select_remark[$i] . "</th>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>

</div>


</html>