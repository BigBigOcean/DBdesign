<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/20
 * Time: 19:53
 */
$ini=parse_ini_file("../config.ini");
$link=mysqli_connect($ini["servername"],$ini["username"],$ini["password"],$ini["dbname"]);
    if(!$link)
    {
        echo "database fail<br>";
    }
    else
    {
        mysqli_select_db($link,"hotel");
       // echo "succed";
    }

?>