<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>

<div class="container event-wrapper">
    <?php
    /*echo '<form id="form1" name="form1" method="post" action="op_room.php">
      <input type="hidden" name="op"  value="5"/>
    </form>';
    echo '<script   language="javascript">
      document.form1.submit();
      </script>';
    */
    //先查询所有的房间
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_room.php">
  <input type="hidden" name="op"  value="26"/>
</form>
    <script   language="javascript">
        document.form.submit()
  </script>
    ';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 26:
                {
                    $select_whole_roomType_id = explode(",", $_POST["select_whole_roomType_id"]);
                    $select_whole_roomType_name = explode(",", $_POST["select_whole_roomType_name"]);
                    $select_whole_roomType = array_combine($select_whole_roomType_id, $select_whole_roomType_name);

//var_dump($select_whole_roomType);
                    $select_room_id = explode(",", $_POST["select_room_id"]);
                    $select_roomType_id = explode(",", $_POST["select_roomType_id"]);
//                var_dump($select_roomType_id);
                    $count_roomType = count($select_whole_roomType_id);
//                var_dump($count_roomType);
                    $count_room = count($select_room_id);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>

    <a href="ManageRoom.php"><input type="button" value="返回上一页"> </a>

    <form action="op_room.php" method="post">
        <table>
            <tr>
                <hr/>
                新增房间
            </tr>
            <tr>
                <th>房号</th>
                <th>房型</th>
            </tr>

            <th><input type="text" name="room_id" value="5"></th>
            <th>
                <select name="roomType_id">
                    <?php
                    for ($i = 0; $i < $count_roomType; $i++) {
                        echo "<option value=" . $select_whole_roomType_id[$i] . ">" . $select_whole_roomType[$select_whole_roomType_id[$i]] . "</option>";
                    }
                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="27">
        <input type="submit" value="增加新房间">
    </form>

    <form action="op_room.php" method="post">
        <table>
            <tr>
                <hr/>
                删除房间
            </tr>
            <th>
                <select name="delete_room_id">
                    <?php //循环显示房间，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_room; $i++) {
                        echo "<option value=" . $select_room_id[$i] . ">" . $select_room_id[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="28">
        <input type="submit" value="删除">
    </form>


    <table>
        <tr>
            <hr/>
            房间信息
        </tr>
        <tr>
            <th>房号</th>
            <th>房型ID</th>
            <th>房型</th>
        </tr>
        <?php
        for ($i = 0; $i < $count_room; $i++) {
            echo "<tr>";
            echo "<th>" . $select_room_id[$i] . "</th>";
            echo "<th>" . $select_roomType_id[$i] . "</th>";
            echo "<th>" . $select_whole_roomType[$select_roomType_id[$i]] . "</th>";
            echo "</tr>";
        }
        ?>
    </table>

</div>


</html>