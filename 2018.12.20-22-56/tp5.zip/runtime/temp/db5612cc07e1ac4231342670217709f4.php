<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\tp5\public/../application/admin\view\index\index.html";i:1538455711;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<title>登录注册界面</title> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="images/login.js"></script>
<link href="../css/login2.css" rel="stylesheet" type="text/css" />
</head>
<!-- <script type="text/javascript">
function showmess1()
{
	alert("hello");
	var res = $("uArea").valueOf();
  alert("user = " + res);
	alert("hello2");
}
</script> -->
<body>

<div class="login" style="margin-top:50px;">
    
    <div class="header">
        <div class="switch" id="switch"><a class="switch_btn_focus" id="switch_qlogin" href="javascript:void(0);" tabindex="7">快速登录</a>
			<a class="switch_btn" id="switch_login" href="javascript:void(0);" tabindex="8">快速注册</a><div class="switch_bottom" id="switch_bottom" style="position: absolute; width: 64px; left: 0px;"></div>
        </div>
    </div>    
  
    
    <div class="web_qr_login" id="web_qr_login" style="display: block; height: 235px;">    

            <!--登录-->
            <div class="web_login" id="web_login">
               <div class="login-box">
    
            
			<div class="login_form">
				<form action="" name="loginform" accept-charset="utf-8" id="login_form" class="loginForm" method="post"><input type="hidden" name="did" value="0"/>
               <input type="hidden" name="to" value="log"/>
                <div class="uinArea" id="uinArea">
                <label class="input-tips" for="u">帐号：</label>
                <div class="inputOuter" id="uArea">
                    
                    <input type="text" id="username" name="username" class="inputstyle"/>
                </div>
                </div>
                <div class="pwdArea" id="pwdArea">
               <label class="input-tips" for="p">密码：</label> 
               <div class="inputOuter" id="pArea">
                    
                    <input type="password" id="password" name="password" class="inputstyle"/>
                </div>
                </div>
               
                <div style="padding-left:50px;margin-top:20px;">
									<input type="submit" value="登 录" style="width:150px;" class="button_blue" />
									</div>
              </form>
           </div>
           
            </div>
               
            </div>
            <!--登录end-->
  </div>

  <!--注册-->
    <div class="qlogin" id="qlogin" style="display: none; ">
   
    <div class="web_login"><form name="form2" id="regUser" accept-charset="utf-8"  action="" method="post">
	      <input type="hidden" name="to" value="reg"/>
		      		       <input type="hidden" name="did" value="0"/>
        <ul class="reg_form" id="reg-ul">
                <li>
                	
                    <label for="user_name"  class="input-tips2">姓名：</label>
                    <div class="inputOuter2">
                        <input type="text" id="user_name" name="user_name" maxlength="16" class="inputstyle2"/>
                    </div>
                    
                </li>
								
								<li>
								<label for="telephone" class="input-tips2">手机号码：</label>
										<div class="inputOuter2">
											
												<input type="text" id="telephone" name="telephone" maxlength="10" class="inputstyle2"/>
										</div>
									
								</li>
                
                <li>
                <label for="passwd" class="input-tips2">密码：</label>
                    <div class="inputOuter2">
                        <input type="password" id="passwd"  name="passwd" maxlength="16" class="inputstyle2"/>
                    </div>
                    
                </li>
                <li>
                <label for="passwd2" class="input-tips2">确认密码：</label>
                    <div class="inputOuter2">
                        <input type="password" id="passwd2" name="" maxlength="16" class="inputstyle2" />
                    </div>
                    
                </li>
						
								<li>
									<label for="IDtype" class="input-tips2" >证件类型：</label>
									<div >
											<link rel="stylesheet" type="text/css" href="css/selectFilter.css" />
											<style type="text/css">
												body {
													padding: 100px;
												}
												.item {
													width: 30dpx;
													height: 0px;
													margin: 10px;
												}
											</style>
			
											<div class="item">
												
												<!-- 这里开始 -->
												<div class="filter-box">
													<div class="filter-text">
														<input class="filter-title" type="text" readonly placeholder="pleace select" />
														<i class="icon icon-filter-arrow"></i>
													</div>
													<select name="filter">
														<option value="shenfenzhen"selected>身份证</option>
														<option value="huzhao">护照</option>
														<option value="bingyizhen">兵役证</option>
													</select>
												</div>
												
												<!-- 这里结束 -->
												
											</div>
											
											<!--
												select   --  name 可以接收选择的值【用于表单提交  名称自定义】
												
												option   --  1.  value    传给后台的参数
															 1.  selected 设置默认选中
															 2.  disabled 设置禁止选则			
											-->
											
											<script type="text/javascript" src="js/jquery.min.js"></script>
											<script type="text/javascript" src="js/selectFilter.js"></script>
											<script type="text/javascript">
												//本小插件支持移动端哦
												
												//这里是初始化
												$('.filter-box').selectFilter({
													callBack : function (val){
														//返回选择的值
														console.log(val+'-是返回的值')
													}
												});
											</script>							
										
									</div>
								</li>
								
                <li>
                 <label for="IDnumber" class="input-tips2">证件号码：</label>
                    <div class="inputOuter2">
                       
                        <input type="text" id="IDnumber" name="IDnumber" maxlength="10" class="inputstyle2"/>
                    </div>
                   
                </li>
                
								
								
                <li>
                    <div class="inputArea">
                        <input type="button" id="reg"  style="margin-top:10px;margin-left:85px;" class="button_blue" value="同意协议并注册"/> <a href="#" class="zcxy" target="_blank">注册协议</a>
                    </div>
                    
                </li><div class="cl"></div>
            </ul></form>
           
    
    </div>
   
    
    </div>
    <!--注册end-->
</div>
</body>

</html>