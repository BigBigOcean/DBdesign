﻿window.onresize=function(){
	var publicw;
	var w=screen.width;
	var h=screen.height;
	var htmlh = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
	var htmlw = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    if(htmlw<=1000){
      publicw=1000;
      }
    else{
    	publicw=w;
    }
	var right_content=document.getElementById("right_content");
	if(right_content!=null){
		right_content.style.width=(w-240-17)+"px";
	}
    var all=document.getElementById("all");
	if(all!=null){
		all.style.width=(w-17)+"px";
	}
}


