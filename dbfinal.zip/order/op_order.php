<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/12/2
 * Time: 23:37
 */
include("../conn.php");
//check in和check out操作
$op = $_POST["op"];
switch ($op) {
    //checkin操作从1开始
    //checkout操作从25开始
    case 1:
        {
            //从manageorder里面checkin
            //首先拿到全部的房间类型
            $query_select_roomType = "SELECT roomType_id,roomType_name FROM roomtype";
            $select_roomType = mysqli_query($link, $query_select_roomType);
            $result = mysqli_fetch_array($select_roomType);
//            var_dump($result);
            $result_whole_roomType_id = array($result["roomType_id"]);
            $result_whole_roomType_name = array($result["roomType_name"]);

            while ($row = mysqli_fetch_array($select_roomType)) {
                $row_whole_roomType_id = array($row["roomType_id"]);
                $row_whole_roomType_name = array($row["roomType_name"]);

                $result_whole_roomType_id = array_merge($result_whole_roomType_id, $row_whole_roomType_id);
                $result_whole_roomType_name = array_merge($result_whole_roomType_name, $row_whole_roomType_name);
            }
//                echo "<hr/>";

            //接着拿到10个consume记录：
            $card_id = $_POST["card_id"];

            $query_comsume = "SELECT transaction_id FROM consume  WHERE card_id='$card_id' ORDER BY consume_time DESC LIMIT 10 ";
            $select_consume = mysqli_query($link, $query_comsume);
            $result = mysqli_fetch_array($select_consume);
            $result_transaction_id = array($result["transaction_id"]);
            while ($row = mysqli_fetch_array($select_consume)) {
                $row_transaction_id = array($row["transaction_id"]);

                $result_transaction_id = array_merge($result_transaction_id, $row_transaction_id);
            }
//            var_dump($result_transaction_id);
            //统计有多少个transaction记录
            $count_transaction = count($result_transaction_id);

            $query_transaction = "SELECT * FROM transaction WHERE transaction_id='$result_transaction_id[0]'";

            $select_transaction = mysqli_query($link, $query_transaction);
            $result = mysqli_fetch_array($select_transaction);

            $result_stuff_id = array($result["stuff_id"]);
            $result_payment_id = array($result["payment_id"]);
            $result_reserve_time = array($result["reserve_time"]);
            $result_reserve_days = array($result["reserve_days"]);
            $result_reserveStore_time = array($result["reserveStore_time"]);
            $result_checkIn_time = array($result["checkIn_time"]);
            $result_leave_time = array($result["leave_time"]);
            $result_transaction_status = array($result["transaction_status"]);
            $result_remark = array($result["remark"]);

            //查询order表
            $query_order = "SELECT room_id,room_status,roomType_id FROM table_order WHERE transaction_id='$result_transaction_id[0]'";

            $select_order = mysqli_query($link, $query_order);
            $result = mysqli_fetch_array($select_order);

            $result_room_id = array($result["room_id"]);
            $result_roomType_id = array($result["roomType_id"]);
            $result_room_status = array($result["room_status"]);

//首先通过拿到的这些transactionid去transaction里面把所有对应的记录拿到，然后再去order里面把对应的room的信息拿到
            //所有传回去checkin，然后如果status是未入住的话出现checkin的按钮，
            //按下checkin之后改变transaction的checkin time还有status还有order里面的status
            for ($i = 1; $i < $count_transaction; $i++) {
                $query_transaction = "SELECT * FROM transaction WHERE transaction_id='$result_transaction_id[$i]'";
                $select_transaction = mysqli_query($link, $query_transaction);
                $result = mysqli_fetch_array($select_transaction);

                $row_stuff_id = array($result["stuff_id"]);
                $row_payment_id = array($result["payment_id"]);
                $row_reserve_time = array($result["reserve_time"]);
                $row_reserve_days = array($result["reserve_days"]);
                $row_reserveStore_time = array($result["reserveStore_time"]);
                $row_checkIn_time = array($result["checkIn_time"]);
                $row_leave_time = array($result["leave_time"]);
                $row_transaction_status = array($result["transaction_status"]);
                $row_remark = array($result["remark"]);

                $result_stuff_id = array_merge($result_stuff_id, $row_stuff_id);
                $result_payment_id = array_merge($result_payment_id, $row_payment_id);
                $result_reserve_time = array_merge($result_reserve_time, $row_reserve_time);
                $result_reserve_days = array_merge($result_reserve_days, $row_reserve_days);
                $result_reserveStore_time = array_merge($result_reserveStore_time, $row_reserveStore_time);
                $result_checkIn_time = array_merge($result_checkIn_time, $row_checkIn_time);
                $result_leave_time = array_merge($result_leave_time, $row_leave_time);
                $result_transaction_status = array_merge($result_transaction_status, $row_transaction_status);
                $result_remark = array_merge($result_remark, $row_remark);

                $query_order = "SELECT room_id,room_status,roomType_id FROM table_order WHERE transaction_id='$result_transaction_id[$i]'";
                $select_order = mysqli_query($link, $query_order);
                $result = mysqli_fetch_array($select_order);

                $row_room_id = array($result["room_id"]);
                $row_roomType_id = array($result["roomType_id"]);
                $row_room_status = array($result["room_status"]);

                $result_room_id = array_merge($result_room_id, $row_room_id);
                $result_roomType_id = array_merge($result_roomType_id, $row_roomType_id);
                $result_room_status = array_merge($result_room_status, $row_room_status);
            }

            //roomtype表的信息
            $result_whole_roomType_id = implode(",", $result_whole_roomType_id);
            $result_whole_roomType_name = implode(",", $result_whole_roomType_name);

            //transaction表的信息
            $result_transaction_id = implode(",", $result_transaction_id);

            $result_stuff_id = implode(",", $result_stuff_id);
            $result_payment_id = implode(",", $result_payment_id);
            $result_reserve_time = implode(",", $result_reserve_time);
            $result_reserve_days = implode(",", $result_reserve_days);
            $result_reserveStore_time = implode(",", $result_reserveStore_time);
            $result_checkIn_time = implode(",", $result_checkIn_time);
            $result_leave_time = implode(",", $result_leave_time);
            $result_transaction_status = implode(",", $result_transaction_status);
            $result_remark = implode(",", $result_remark);

            //order表的信息
            $result_room_id = implode(",", $result_room_id);
            var_dump($result_room_id);
            $result_roomType_id = implode(",", $result_roomType_id);
            $result_room_status = implode(",", $result_room_status);

            echo "
            <form action='check_in.php' method='post' name='form'>
                <input type='hidden' name='whole_roomType_id' value='" . $result_whole_roomType_id . "'>
                <input type='hidden' name='whole_roomType_name' value='" . $result_whole_roomType_name . "'>

                 <input type='hidden' name='card_id' value='" . $card_id . "'>

                <input type='hidden' name='transaction_id' value='" . $result_transaction_id . "'>
                <input type='hidden' name='stuff_id' value='" . $result_stuff_id . "'>
                <input type='hidden' name='payment_id' value='" . $result_payment_id . "'>
                <input type='hidden' name='reserve_time' value='" . $result_reserve_time . "'>
                <input type='hidden' name='reserve_days' value='" . $result_reserve_days . "'>
                <input type='hidden' name='reserveStore_time' value='" . $result_reserveStore_time . "'>
                <input type='hidden' name='checkIn_time' value='" . $result_checkIn_time . "'>
                <input type='hidden' name='leave_time' value='" . $result_leave_time . "'>
                <input type='hidden' name='transaction_status' value='" . $result_transaction_status . "'>
                <input type='hidden' name='remark' value='" . $result_remark . "'>

                <input type='hidden' name='room_id' value='" . $result_room_id . "'>
                <input type='hidden' name='roomType_id' value='" . $result_roomType_id . "'>
                <input type='hidden' name='room_status' value='" . $result_room_status . "'>
                <script language='JavaScript'>
                    document.form.submit();
                </script>
            </form>
            ";

            break;
        }
    case 2:
        {
            $card_id = $_POST["card_id"];
            $transaction_id = $_POST["transaction_id"];
            $room_id = $_POST["room_id"];

            $query_checkin_transaction = "UPDATE transaction SET checkIn_time=CURRENT_TIMESTAMP, transaction_status=1 WHERE transaction_id='$transaction_id'";
            $query_checkin_order = "UPDATE table_order SET room_status=1 WHERE transaction_id='$transaction_id'";

            if (!mysqli_query($link, $query_checkin_transaction)) {
                echo "<a href='ManageOrder.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            }
            if (!mysqli_query($link, $query_checkin_order)) {
                echo "<a href='ManageOrder.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                echo "<p>顾客" . $card_id . " 成功Check In </p>";
                echo "<p>房号" . $room_id . " 成功Check In <hr/></p>";
                echo "
                <form action='op_order.php' method='post'>
                    <input type='hidden' name='card_id' value='" . $card_id . "'>
                    <input type='hidden' name='op' value='1'>
                    <input type='submit' value='返回上一页'>
                
                </form>
                ";

            }
            break;
        }
    case 25:
        {
            //从manageorder里面checkout
            $room_id = $_POST["room_id"];
            $query_checkout = "SELECT * FROM table_order WHERE room_id='$room_id' AND room_status=1 ";
            $tmp_result = mysqli_query($link, $query_checkout);
            $result = mysqli_fetch_array($tmp_result);
//            var_dump($result);
            echo "
            <form action='check_out.php' method='post' name='form'>
                <input type='hidden' name='room_id' value='" . $result['room_id'] . "'>
                <input type='hidden' name='transaction_id' value='" . $result['transaction_id'] . "'>
                <input type='hidden' name='room_status' value='" . $result['room_status'] . "'>
                <script language='javascript'>
                    document.form.submit();
                </script>           
            </form>
            ";
            break;
        }
    case 26:
        {
            $room_id = $_POST["room_id"];
            $transaction_id = $_POST["transaction_id"];
            //先完成checkout的roomstatus改变
            $query_checkout_roomstatus = "UPDATE table_order SET room_status=2 WHERE room_id='$room_id' AND transaction_id='$transaction_id'";
            if (!mysqli_query($link, $query_checkout_roomstatus)) {
                echo "<a href='ManageOrder.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            }

            //在transaction里面记录leavetime，然后改变transactionstatus
            $query_checkout_transaction = "UPDATE transaction SET leave_time=CURRENT_TIMESTAMP,transaction_status=3 WHERE transaction_id='$transaction_id'";
            if (!mysqli_query($link, $query_checkout_transaction)) {
                echo "<a href='ManageOrder.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                echo "<p><hr/>房号" . $room_id . " 成功退房</p>";
                echo "<a href='ManageOrder.php'><input type='button' value='返回上一页'> </a><br/>";
            }

            break;
        }
    default:
        {
            echo "Error: illegal get into this page";
        }

}
?>