<html>
<!--<form action="op_job.php" method="post" name="lookforjobs">-->
<!--    <input type="hidden" value="5" name="op">-->
<!--</form>-->
<!--<script type-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>
<div class="container event-wrapper">
    <?php
    //先查询所有的职位 和员工信息
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_job.php">
  <input type="hidden" name="op"  value="5"/>
</form>
    <script   language="javascript">
        document.form.submit()
  </script>
    ';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 5:
                {
                    $select_job_id = explode(",", $_POST["select_job_id"]);
                    $select_job_name = explode(",", $_POST["select_job_name"]);
//                var_dump($select_job_name);
                    $count_job = count($select_job_name);
//                $selec_job = array_combine($select_job_id, $select_job_name);
//                var_dump($selec_job);

                    $select_stuff_id = explode(",", $_POST["select_stuff_id"]);
                    $select_stuff_name = explode(",", $_POST["select_stuff_name"]);
                    $select_sex = explode(",", $_POST["select_sex"]);
                    $select_phone = explode(",", $_POST["select_phone"]);
                    $select_card = explode(",", $_POST["select_card"]);
                    $select_join_time = explode(",", $_POST["select_join_time"]);
                    $select_stuff_job_id = explode(",", $_POST["select_stuff_job_id"]);
                    $select_birth_time = explode(",", $_POST["select_birth_time"]);

                    $count_stuff = count($select_stuff_id);

                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>

    <a href="ManageStuff.php"><input type="button" value="返回上一页"></a>
    <form action="search.php" method="post">
        <table>
            <tr>
                <hr/>
                查询
            </tr>
            <tr>
                <th>
                    <select name="search_stuff_type">
                        <option value="1">按ID搜索</option>
                        <option value="2">按名字搜索</option>
                        <option value="3">按职位搜索</option>
                    </select>
                </th>
                <th>
                    <input type="text" name="search_stuff" value="1">
                </th>

            </tr>
        </table>
        <input type="hidden" name="op_search" value="2">
        <input type="submit" value="查询">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr></hr>
                增加新员工:
            </tr>
            <tr>
                <th>名字</th>
                <th>性别</th>
                <th>手机号</th>
                <th>身份证号</th>
                <th>生日</th>
                <th>职位</th>
            </tr>
            <tr>
                <th><input type="text" name="stuff_name" value="jack"></th>
                <th>
                    <select name="sex">
                        <option value="0">女</option>
                        <option value="1">男</option>
                    </select>
                </th>
                <th><input type="text" name="phone" value="123456789"></th>
                <th><input type="text" name="card_id" value="1"</th>
                <th><input type="date" name="birth_time"</th>
                <th>
                    <select name="selected_job">
                        <?php //循环显示职位，下拉列表选择
                        //                    $test = "what";
                        for ($i = 0; $i < $count_job; $i++) {
                            echo "<option value=" . $select_job_id[$i] . ">" . $select_job_name[$i] . "</option>";
                        }

                        ?>
                    </select>
                </th>
            </tr>

        </table>
        <input type="hidden" name="op" value="6">
        <input type="submit" value="增加员工">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr></hr>
                删除员工
            </tr>
            <tr>
                <th>员工ID</th>
            </tr>
            <tr>
                <th><input type="text" name="delete_stuff_id" value="1"></th>
            </tr>
        </table>
        <input type="hidden" name="op" value="7">
        <input type="submit" value="删除员工">
    </form>

    <form action="op_job.php" method="post">
        <table>
            <tr>
                <hr/>
                编辑员工信息
            </tr>
            <tr>
                <th>员工ID</th>
                <th>名字</th>
                <th>性别</th>
                <th>联系方式</th>
                <th>身份证号</th>
                <th>生日</th>
            </tr>
            <tr>
                <th>
                    <select name="edit_stuff_id">
                        <?php //循环显示职位，下拉列表选择
                        //                    $test = "what";
                        for ($i = 1; $i <= $count_stuff; $i++) {
                            echo "<option value=" . $i . ">" . $i . "</option>";
                        }
                        ?>
                    </select>
                </th>
                <th>
                    <input type="text" name="edit_stuff_name">
                </th>
                <th>
                    <select name="edit_sex">
                        <option value="">不修改</option>
                        <option value="0">female</option>
                        <option value="1">male</option>
                    </select>
                    <!--                <input type="text" name="edit_sex">-->
                </th>
                <th>
                    <input type="text" name="edit_phone">
                </th>
                <th>
                    <input type="text" name="edit_card">
                </th>
                <th>
                    <input type="date" name="edit_birth_time">
                </th>
            </tr>
        </table>
        <input type="hidden" name="op" value="8">
        <input type="submit" value="提交">
    </form>

    <table>
        <tr>员工信息</tr>
        <tr>
            <th>员工ID</th>
            <th>姓名</th>
            <th>性别</th>
            <th>联系方式</th>
            <th>身份证号</th>
            <th>入职时间</th>
            <th>职位</th>
            <th>生日</th>
        </tr>
        <tr>
            <?php
            if ($count_stuff > 1) {
                for ($i = 0; $i < $count_stuff; $i++) {
                    echo "<tr>";
                    echo "<th>" . $select_stuff_id[$i] . "</th>";
                    echo "<th>" . $select_stuff_name[$i] . "</th>";
                    if ($select_sex[$i] == 0) {
                        echo "<th>female</th>";
                    } else {
                        echo "<th>male</th>";
                    }
                    echo "<th>" . $select_phone[$i] . "</th>";
                    echo "<th>" . $select_card[$i] . "</th>";
                    echo "<th>" . $select_join_time[$i] . "</th>";
                    echo "<th>" . $select_job_name[$select_stuff_job_id[$i] - 1] . "</th>";
                    echo "<th>" . $select_birth_time[$i] . "</th>";
                }
            } else {
                echo "<tr><th>没有员工</th></th></tr>";
            }

            ?>
        </tr>
    </table>
</div>


</html>