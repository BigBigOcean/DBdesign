﻿<html>
<head>
    <link rel="stylesheet" type="text/css" href="../home/css/nav.css" />
    <meta content="text/html; charset=utf-8" />
</head>
<body class="center-in-center">
<ul>
    <li><a href="EditJob.php">管理职位</a></li>
    <li><a href="EditStuff.php">管理员工</a></li>
</ul>
<a href="../test.php">返回上一页</a>
</body>

</html>