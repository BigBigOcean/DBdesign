<html>
<!--只用一个房间号即可完成check out-->
<!--只用一个身份证号即可完成check in-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>

<div class="container event-wrapper">

    <a href="../test.php"><input type="button" value="返回上一页"></a>
    <form action="op_order.php" method="post">
        <p>
        <hr/>
        Check in(输入顾客证件号):
        </p>
        <p>
            <input type="text" name="card_id" value="201630665656">
        </p>

        <input type="hidden" name="op" value="1">

        <p>
            <input type="submit" value="check in">
        </p>
    </form>

    <form action="op_order.php" method="post">
        <p>
        <hr/>
        Check out(输入房号):
        </p>
        <p>
            <input type="text" name="room_id" value="5">
        </p>

        <input type="hidden" name="op" value="25">

        <p>
            <input type="submit" value="check out">
        </p>
    </form>
</div>

</html>