﻿<html>
<head>
    <link rel="stylesheet" type="text/css" href="home/css/nav.css"/>
    <meta content="text/html; charset=utf-8" />
</head>
<head>
    <title>酒店后台管理</title>
</head>

<body class="center-in-center">

<ul>
    <li><a href="thing/ManageThing.php">物品管理</a></li>
    <li><a href="stuff/ManageStuff.php">职工管理</a></li>
    <li><a href="room/ManageRoom.php">房间房型管理</a></li>
    <li><a href="service/ManageService.php">服务管理</a></li>
    <li><a href="order/ManageOrder.php">订单管理</a></li>
    <li><a href="../tp5/public">返回首页</a></li>
</ul>
</body>

</html>
