<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>

<div class="container event-wrapper">

    <?php
    //自定义函数
    function test()
    {
        echo "test";
    }

    function bool2chinese($i)
    {
        if ($i == 0) {
            return "√";
        } else {
            return "×";
        }
    }

    ?>

    <?php
    //edittype所有操作op从1到25

    //先查询所有的物品种类
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_room.php">
    <input type="hidden" name="op"  value="50"/>
</form>
<script   language="javascript">
    document.form.submit()
</script>
';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 50:
                {
//                var_dump($_POST["select_room_name"]);
                    $select_roomType_id = explode(",", $_POST["select_roomType_id"]);
//                var_dump($select_room_id);
                    $select_roomType_name = explode(",", $_POST["select_roomType_name"]);
//                var_dump($select_room_name);
                    $select_max_num = explode(",", $_POST["select_max_num"]);
                    $select_price = explode(",", $_POST["select_price"]);
                    $select_blcony_has = explode(",", $_POST["select_blcony_has"]);
                    $select_toilet_has = explode(",", $_POST["select_toilet_has"]);
                    $select_wifi_has = explode(",", $_POST["select_wifi_has"]);
                    $select_ac_has = explode(",", $_POST["select_ac_has"]);
                    $select_tv_has = explode(",", $_POST["select_tv_has"]);
                    $select_breakfast_num = explode(",", $_POST["select_breakfast_num"]);
                    $select_singlebed_num = explode(",", $_POST["select_singlebed_num"]);
                    $select_doublebed_num = explode(",", $_POST["select_doublebed_num"]);
//                var_dump($select_salary);
                    $count_room = count($select_roomType_id);
//                $selec_room = array_combine($select_room_id, $select_room_name);
//                var_dump($selec_room);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>
    <a href="Manageroom.php"><input type="button" value="返回上一页"></a>

    <p>
    <hr/>
    增加房型：</p>
    <form action="op_room.php" method="post">
        <table>
            <tr>
                <th>房型名字</th>
                <th>最大数量</th>
                <th>价格</th>
                <th>阳台</th>
                <th>厕所</th>
                <th>WIFI</th>
                <th>空调</th>
                <th>电视</th>
                <th>早餐数</th>
                <th>单人床数</th>
                <th>双人床数</th>
            </tr>
            <tr>
                <td><input type="text" name="roomType_name" value="test"></td>
                <td><input type="text" name="max_num" value="5"></td>
                <td><input type="text" name="price" value="500"></td>
                <td>
                    <select name="blcony_has">
                        <option value="0">无</option>
                        <option value="1">有</option>
                    </select>
                </td>
                <td>
                    <select name="toilet_has">
                        <option value="0">无</option>
                        <option value="1">有</option>
                    </select>
                </td>
                <td>
                    <select name="wifi_has">
                        <option value="0">无</option>
                        <option value="1">有</option>
                    </select>
                </td>
                <td>
                    <select name="ac_has">
                        <option value="0">无</option>
                        <option value="1">有</option>
                    </select>
                </td>
                <td>
                    <select name="tv_has">
                        <option value="0">无</option>
                        <option value="1">有</option>
                    </select>
                </td>
                <td><input type="text" name="breakfast_num" value="2"></td>
                <td><input type="text" name="singlebed_num" value="1"></td>
                <td><input type="text" name="doublebed_num" value="1"></td>
            </tr>
        </table>
        <br/>
        <input type="hidden" name='op' value="1">
        <input type="submit" value="提交">
    </form>

    <form action="op_room.php" method="post">
        <table>
            <tr>
                <hr/>
                删除房型
            </tr>
            <th>
                <select name="delete_roomType_name">
                    <?php //循环显示物品，下拉列表选择
                    //                    $test = "what";
                    for ($i = 0; $i < $count_room; $i++) {
                        echo "<option value=" . $select_roomType_id[$i] . ">" . $select_roomType_name[$i] . "</option>";
                    }

                    ?>
                </select>
            </th>
        </table>
        <input type="hidden" name="op" value="2">
        <input type="submit" value="删除">
    </form>

    <table>
        <tr>
            <hr/>
            房型信息
        </tr>
        <tr>
            <th>房型ID</th>
            <th>房型名</th>
            <th>最大数量</th>
            <th>价格</th>
            <th>阳台</th>
            <th>厕所</th>
            <th>WIFI</th>
            <th>空调</th>
            <th>电视</th>
            <th>早餐数</th>
            <th>单人床数</th>
            <th>双人床数</th>
        </tr>
        <?php
        for ($i = 0; $i < $count_room; $i++) {
            echo "<tr>";
            echo "<th>" . $select_roomType_id[$i] . "</th>";
            echo "<th>" . $select_roomType_name[$i] . "</th>";
            echo "<th>" . $select_max_num[$i] . "</th>";
            echo "<th>" . $select_price[$i] . "</th>";
            echo "<th>" . bool2chinese($select_blcony_has[$i]) . "</th>";
            echo "<th>" . bool2chinese($select_toilet_has[$i]) . "</th>";
            echo "<th>" . bool2chinese($select_wifi_has[$i]) . "</th>";
            echo "<th>" . bool2chinese($select_ac_has[$i]) . "</th>";
            echo "<th>" . bool2chinese($select_tv_has[$i]) . "</th>";
            echo "<th>" . $select_breakfast_num[$i] . "</th>";
            echo "<th>" . $select_singlebed_num[$i] . "</th>";
            echo "<th>" . $select_doublebed_num[$i] . "</th>";
            echo "</tr>";
        }
        ?>
    </table>

</div>

</html>