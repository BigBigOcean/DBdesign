<?php
/**
 * Created by PhpStorm.
 * User: 56989
 * Date: 2018/12/19
 * Time: 14:49
 */

namespace app\detail\controller;
use think\Controller;

class Index
{
    public function index()
    {
        return view('showdetail');
    }
}