<html>
<a href="ManageOrder.php"><input type="button" value="返回上一页"></a>
<p><hr/>查询结果：</p>
<?php
$room_id=$_POST["room_id"];
//var_dump($room_id);
if($room_id!="")
{
    $transaction_id=$_POST["transaction_id"];
    $room_status=$_POST["room_status"];

    echo '
        <form action="op_order.php" method="post">
            <table>
                <tr>
                    <th>
                        房号
                    </th>
                    <th>
                        订单号
                    </th>
                    <th>
                        房间状态
                    </th>
                </tr>
                <tr>
                    <th>
                        '.$room_id.'
                    </th>
                    <th>
                        '.$transaction_id.'
                    </th>
                    <th>
                       入住中
                    </th>
                    <th>
                        <input type="hidden" name="room_id" value="'.$room_id.'">
                        <input type="hidden" name="transaction_id" value="'.$transaction_id.'">
                        <input type="hidden" name="op" value="26">
                        <input type="submit" value="Check Out">
                    </th>
                </tr>
            </table>
        </form>
        ';
}
else
{
    echo"该房号没有需要Check Out的";
}


?>

</html>