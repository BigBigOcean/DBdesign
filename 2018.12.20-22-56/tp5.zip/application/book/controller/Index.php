<?php
/**
 * Created by PhpStorm.
 * User: 56989
 * Date: 2018/11/3
 * Time: 15:04
 */

namespace app\book\controller;
use think\Controller;
use think\Db;

class Index extends Controller
{
    public function index()
    {
        return view('book');
    }


    public function whatTypeId($roomType)
    {
        switch ($roomType)
        {
            case 'stdsingle':
                return 1;
            case 'stddouble':
                return 2;
            case 'luxsingle':
                return 3;
            case 'luxdouble':
                return 4;
            case 'family':
                return 5;
            default:
                return -1;
        }
    }

     public function doBook($totmoney, $arrival_date, $leave_date, $room_type, $guest_number, $guest_name, $guest_sex, $card_type, $ID_number, $guest_telephone, $message, $fitRoomId)
    {
        $currentTime = date("YmdHis");
        $howmanyDays = (strtotime($leave_date) - strtotime($arrival_date))/(3600*24);

        $data2payment = ['way'=>1, 'totalFee'=>$totmoney, 'hadPayFee'=>$totmoney, 'payment_time'=>$currentTime, 'remark'=>$message];
        $payment_id = Db::table('payment')->insertGetId($data2payment);

        $data2transaction = ['stuff_id'=>1, 'payment_id'=>$payment_id, 'reserve_time'=>$arrival_date, 'reserve_days'=>$howmanyDays, 'reserveStore_time'=>$currentTime,
            'checkIn_time'=>$arrival_date, 'leave_time'=>$leave_date, 'transaction_status'=>0, 'remark'=>' '];
        $tran_id = Db::table('transaction')->insertGetId($data2transaction);

        $data2consume = ['card_id'=>$ID_number, 'transaction_id'=>$tran_id, 'consume_time'=>$currentTime];
        Db::table('consume')->insert($data2consume);

        $room_type = $this->whatTypeId($room_type);
        $data2table_order = ['room_id'=>$fitRoomId, 'transaction_id'=>$tran_id, 'roomType_id'=>$room_type, 'room_status'=>0];
        Db::table('table_order')->insert($data2table_order);
        
        return true;

    }
    
    public function findName($customer_id)
    {
        $db = Db::name('hotel');       
        $tranSet = $db->query('select customer_name from customer where card_id = ? ',[$customer_id]);
        //return $tranSet;
        return ['doRes'=> $tranSet];

    }

}