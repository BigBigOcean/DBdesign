<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\tp5\public/../application/index\view\index\index.html";i:1539689992;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<h1>this is view/index/index.html</h1>
<h2>数据库测试界面</h2>

<form method="post" action="<?php echo url('index/index'); ?>">
    <table>
        <tr>
            <td>输入要查询的id:</td>
        </tr>
        <tr>
            <td><input type="text" name="input_id"></td>
        </tr>
    </table>
    <input type="submit" value="提交">
</form>




</body>
</html>