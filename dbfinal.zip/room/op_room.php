<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 2018/11/20
 * Time: 21:04
 */

//edittype所有操作op从1到25
include("../conn.php");
//房间操作
$op = $_POST["op"];
switch ($op) {
    //从edittype加入新的物品类型
    case 1:
        {
            $roomType_name = $_POST["roomType_name"];
            $max_num = $_POST["max_num"];
            $price = $_POST["price"];
            $blcony_has = $_POST["blcony_has"];
            $toilet_has = $_POST["toilet_has"];
            $wifi_has = $_POST["wifi_has"];
            $ac_has = $_POST["ac_has"];
            $tv_has = $_POST["tv_has"];
            $breakfast_num = $_POST["breakfast_num"];
            $singlebed_num = $_POST["singlebed_num"];
            $doublebed_num = $_POST["doublebed_num"];
//insert
            $query_select_max = "SELECT MAX(roomType_id) FROM roomtype ";
            $max_roomTypeid = mysqli_query($link, $query_select_max);
            $roomType_id;
            while ($row = mysqli_fetch_array($max_roomTypeid)) {
                $roomType_id = $row['MAX(roomType_id)'] + 1;
            }
            $query_roomType = "INSERT INTO roomtype(roomType_id,roomType_name,max_num,price,blcony_has,toilet_has,
wifi_has,ac_has,tv_has,breakfast_num,singlebed_num,doublebed_num)
                              VALUES('$roomType_id','$roomType_name','$max_num','$price','$blcony_has','$toilet_has',
                              '$wifi_has','$ac_has','$tv_has','$breakfast_num','$singlebed_num','$doublebed_num')";

            if (!mysqli_query($link, $query_roomType)) {
                echo "<a href='EditType.php'><input type='button' value='返回上一页'> </a><br/>";
                die('Error: ' . mysqli_error($link));
            } else {
                header("location:EditType.php");
            }
            break;
        }
    case 2://从edittype删除物品
        {
            $delete_roomType_id = $_POST["delete_roomType_name"];
            $query_delete_roomType = "DELETE FROM roomtype WHERE roomType_id='$delete_roomType_id'";
            if (!mysqli_query($link, $query_delete_roomType)) {
                echo "<a href='EditType.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                header("location:EditType.php");
            }
            break;
        }


    case 26://查询所有的room返回editroom
        {
            $query_select_roomType = "SELECT roomType_id,roomType_name FROM roomtype";
            $select_roomType = mysqli_query($link, $query_select_roomType);
            $result = mysqli_fetch_array($select_roomType);
//            var_dump($result);
            $result_whole_roomType_id = array($result["roomType_id"]);
            $result_whole_roomType_name = array($result["roomType_name"]);

            while ($row = mysqli_fetch_array($select_roomType)) {
                $row_whole_roomType_id = array($row["roomType_id"]);
                $row_whole_roomType_name = array($row["roomType_name"]);

                $result_whole_roomType_id = array_merge($result_whole_roomType_id, $row_whole_roomType_id);
                $result_whole_roomType_name = array_merge($result_whole_roomType_name, $row_whole_roomType_name);
            }
//                echo "<hr/>";
            $result_whole_roomType_id = implode(",", $result_whole_roomType_id);
            $result_whole_roomType_name = implode(",", $result_whole_roomType_name);

            $query_select_room = "SELECT * FROM room";
            $select_room = mysqli_query($link, $query_select_room);
            $result = mysqli_fetch_array($select_room);
            $result_room_id = array($result["room_id"]);
            $result_roomType_id = array($result["roomType_id"]);
            while ($row = mysqli_fetch_array($select_room)) {
                $row_room_id = array($row["room_id"]);
                $row_roomType_id = array($row["roomType_id"]);

                $result_room_id = array_merge($result_room_id, $row_room_id);
                $result_roomType_id = array_merge($result_roomType_id, $row_roomType_id);
            }
//                echo "<hr/>";
            $result_room_id = implode(",", $result_room_id);
//            var_dump($result_roomType_id);
            $result_roomType_id = implode(",", $result_roomType_id);

//var_dump($result_whole_roomType_id );
            mysqli_close($link);
            echo '<form  name="form" method="post" action="EditRoom.php">
<input type="hidden" name="op"  value="26"/>
<input type="hidden" name="select_whole_roomType_id"  value="' . $result_whole_roomType_id . '"/>
<input type="hidden" name="select_whole_roomType_name"  value="' . $result_whole_roomType_name . '"/>
  <input type="hidden" name="select_room_id"  value="' . $result_room_id . '"/>
  <input type="hidden" name="select_roomType_id"  value="' . $result_roomType_id . '"/>
                  <script   language="javascript">
                document.form.submit();
  </script>
    </form>

        ';
            break;
        }
    case 27://从editroom增加新房间
        {
            $room_id = $_POST["room_id"];
            $roomType_id = $_POST["roomType_id"];
//insert
            $query_room = "INSERT INTO room(room_id,roomType_id)
                              VALUES('$room_id','$roomType_id')";

            if (!mysqli_query($link, $query_room)) {
                echo "<a href='EditRoom.php'><input type='button' value='返回上一页'> </a><br/>";
                die('Error: ' . mysqli_error($link));
            } else {
                header("location:EditRoom.php");
            }
            break;
        }
    case 28://从editroom删除房间
        {
            $delete_room_id = $_POST["delete_room_id"];
            $query_delete_room = "DELETE FROM room WHERE room_id='$delete_room_id'";
            if (!mysqli_query($link, $query_delete_room)) {
                echo "<a href='EditRoom.php'><input type='button' value='返回上一页'> </a><br/>";
                die("Error: " . mysqli_error($link));
            } else {
                mysqli_close($link);
                header("location:EditRoom.php");
            }
            break;
        }
    case 50://查询所有房型返回edittype
        {
            $query_select_roomtype = "SELECT * FROM roomtype ORDER BY roomType_id ASC";
            $select_roomtype = mysqli_query($link, $query_select_roomtype);
//                var_dump($select_roomType);
            $result = mysqli_fetch_array($select_roomtype);
            $result_roomType_id = array($result["roomType_id"]);
            $result_roomType_name = array($result["roomType_name"]);
            $result_max_num = array($result["max_num"]);
            $result_price = array($result["price"]);
            $result_blcony_has = array($result["blcony_has"]);
            $result_toilet_has = array($result["toilet_has"]);
            $result_wifi_has = array($result["wifi_has"]);
            $result_ac_has = array($result["ac_has"]);
            $result_tv_has = array($result["tv_has"]);
            $result_breakfast_num = array($result["breakfast_num"]);
            $result_singlebed_num = array($result["singlebed_num"]);
            $result_doublebed_num = array($result["doublebed_num"]);
//var_dump($result);

            while ($row = mysqli_fetch_array($select_roomtype)) {
                $row_roomType_id = array($row["roomType_id"]);
                $row_roomType_name = array($row["roomType_name"]);
                $row_max_num = array($row["max_num"]);
                $row_price = array($row["price"]);
                $row_blcony_has = array($row["blcony_has"]);
                $row_toilet_has = array($row["toilet_has"]);
                $row_wifi_has = array($row["wifi_has"]);
                $row_ac_has = array($row["ac_has"]);
                $row_tv_has = array($row["tv_has"]);
                $row_breakfast_num = array($row["breakfast_num"]);
                $row_singlebed_num = array($row["singlebed_num"]);
                $row_doublebed_num = array($row["doublebed_num"]);

                $result_roomType_id = array_merge($result_roomType_id, $row_roomType_id);
                $result_roomType_name = array_merge($result_roomType_name, $row_roomType_name);
                $result_max_num = array_merge($result_max_num, $row_max_num);
                $result_price = array_merge($result_price, $row_price);
                $result_blcony_has = array_merge($result_blcony_has, $row_blcony_has);
                $result_toilet_has = array_merge($result_toilet_has, $row_toilet_has);
                $result_wifi_has = array_merge($result_wifi_has, $row_wifi_has);
                $result_ac_has = array_merge($result_ac_has, $row_ac_has);
                $result_tv_has = array_merge($result_tv_has, $row_tv_has);
                $result_breakfast_num = array_merge($result_breakfast_num, $row_breakfast_num);
                $result_singlebed_num = array_merge($result_singlebed_num, $row_singlebed_num);
                $result_doublebed_num = array_merge($result_doublebed_num, $row_doublebed_num);

//                    echo "<hr/>";
            }
//                echo "<hr/>";
            $result_roomType_id = implode(",", $result_roomType_id);
            $result_roomType_name = implode(",", $result_roomType_name);
            $result_max_num = implode(",", $result_max_num);
            $result_price = implode(",", $result_price);
            $result_blcony_has = implode(",", $result_blcony_has);
            $result_toilet_has = implode(",", $result_toilet_has);
            $result_wifi_has = implode(",", $result_wifi_has);
            $result_ac_has = implode(",", $result_ac_has);
            $result_tv_has = implode(",", $result_tv_has);
            $result_breakfast_num = implode(",", $result_breakfast_num);
            $result_singlebed_num = implode(",", $result_singlebed_num);
            $result_doublebed_num = implode(",", $result_doublebed_num);
//                var_dump($result_salary);
//               var_dump($result_roomType_name);
//               $result=explode(",",$result);
//               var_dump($result);
//
            mysqli_close($link);
            echo '<form  name="form" method="post" action="EditType.php">
<input type="hidden" name="op"  value="50"/>
  <input type="hidden" name="select_roomType_id"  value="' . $result_roomType_id . '"/>
  <input type="hidden" name="select_roomType_name"  value="' . $result_roomType_name . '"/>
  <input type="hidden" name="select_max_num"  value="' . $result_max_num . '"/>
  <input type="hidden" name="select_price"  value="' . $result_price . '"/>
  <input type="hidden" name="select_blcony_has"  value="' . $result_blcony_has . '"/>
  <input type="hidden" name="select_toilet_has"  value="' . $result_toilet_has . '"/>
  <input type="hidden" name="select_wifi_has"  value="' . $result_wifi_has . '"/>
  <input type="hidden" name="select_ac_has"  value="' . $result_ac_has . '"/>
  <input type="hidden" name="select_tv_has"  value="' . $result_tv_has . '"/>
  <input type="hidden" name="select_breakfast_num"  value="' . $result_breakfast_num . '"/>
  <input type="hidden" name="select_singlebed_num"  value="' . $result_singlebed_num . '"/>
  <input type="hidden" name="select_doublebed_num"  value="' . $result_doublebed_num . '"/>

                  <script   language="javascript">
                document.form.submit();
            </script>
            </form>
            ';
            break;
        }
    default:
        {
            echo "Error: illegal get into this page";
        }

}


mysqli_close($link);

//echo "<script>window.location.href='AddNewroomTypeType.php'</script>";
?>