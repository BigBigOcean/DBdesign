<?php

namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    public function index()
    {
        return view('show');
    }



//    public function add()
//    {
//        if(request()->isPost())
//        {
//            dump("查询");
//            $request = Request::instance();
//            $data = $request->post();
//            dump($data);
//            //dump($data["input_id"]);
//
//            $db = Db::name('student');
//            $db->insert([
//                'id'  => $data["input_id"],
//                'name' => $data["input_name"]
//            ]);
//        }
//    }

    public function anotherTest($roomType,$startTime, $endTime, $guestNumber)
    {
        //dump("收到信息");
        return (['type'=>$roomType, 'time1'=>$startTime, 'time2'=>$endTime, 'guestNumber'=>$guestNumber]);
    }

    public function mytest($roomType,$comeTime, $leaveTime)
    {
//        $data['msg'] = '你好';
//        $data['tel'] = '123456';
//        return ['mydata'=>$data, 'code'=>1, 'message'=>'操作完成'];
        //echo ($roomType);
        //echo ($comeTime);
        //echo ($leaveTime);
        return ['type'=>$roomType, 'time1'=>$comeTime, 'time2'=>$leaveTime];
    }



}














