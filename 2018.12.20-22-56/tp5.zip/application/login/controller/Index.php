<?php
/**
 * Created by PhpStorm.
 * User: 56989
 * Date: 2018/11/13
 * Time: 20:39
 */

namespace app\login\controller;


class Index
{
    public function index()
    {
        return view('login');
    }
}