$(document).ready(function(){
	$(".right_content_top a").mouseover(function(){
		$(this).css("transition-duration","0s");
    	$(this).css("transform","scale(1.3");
	})
	$(".right_content_top a").mouseleave(function(){
		$(this).css("transition-duration","0s");
    	$(this).css("transform","scale(1)");
	})
})