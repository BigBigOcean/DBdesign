<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Sign up</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../home/css/home.css">
    <link rel="stylesheet" href="../home/css/event.css">
</head>
<div class="container event-wrapper">

    <?php
    //先查询所有的物品种类
    if (!isset($_POST["op"])) {
        echo '<form id="form" name="form" method="post" action="op_thing.php">
    <input type="hidden" name="op"  value="49"/>
</form>
<script   language="javascript">
    document.form.submit()
</script>
';

    } else//查询完成
    {
        $op = $_POST["op"];
        switch ($op) {
            case 50:
                {
                    $select_thing_id = explode(",", $_POST["select_thing_id"]);
                    $select_thing_name = explode(",", $_POST["select_thing_name"]);
//                $select_thing_num = explode(",", $_POST["select_thing_num"]);
//                $select_position= explode(",", $_POST["select_position"]);
//                $select_repairphone = explode(",", $_POST["select_repairphone"]);
//                $select_remark = explode(",", $_POST["select_remark"]);
                    $count_thing = count($select_thing_id);
                    break;
                }
            default:
                {
                    echo "error";
                    break;
                }

        }
    }
    ?>
    <!--从25开始-->
    <a href="ManageThing.php"><input type="button" value="返回上一页"></a>
    <form action="op_thing.php" method="post">
        <table>
            <tr>
                <hr/>
                添加新物品：
            </tr>
            <tr>
                <th>
                    房号
                </th>
                <th>
                    物品
                </th>
                <th>
                    物品状态
                </th>
            </tr>
            <tr>
                <th>
                    <input type="text" name="room_id" value="5">
                </th>
                <th>
                    <select name="thing_id">
                        <?php
                        for ($i = 0; $i < $count_thing; $i++) {
                            echo "<option value=" . $select_thing_id[$i] . ">" . $select_thing_name[$i] . "</option>";
                        }
                        ?>
                    </select>
                </th>
                <th>
                    <input type="text" name="thing_status" value="1">
                </th>
            </tr>
        </table>
        <input type="hidden" name="op" value="26">
        <input type="submit" value="增加">
    </form>
    <p>
    <hr/>
    查询房号</p>
    <form action="search.php" method="post">
        <input type="text" name="search_room_id" value="5">
        <input type="hidden" name="op_search" value="27">
        <input type="submit" value="查询">
    </form>
</div>

</html>