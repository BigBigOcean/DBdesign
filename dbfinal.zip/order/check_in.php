<html>
<a href="ManageOrder.php"><input type="button" value="返回上一页"></a>
<p>
<hr/>
查询结果：</p>
<?php
//所有的roomtype信息
$whole_roomType_id = explode(",", $_POST["whole_roomType_id"]);
$whole_roomType_name = explode(",", $_POST["whole_roomType_name"]);
//var_dump($whole_roomType_name);
$roomType = array_combine($whole_roomType_id, $whole_roomType_name);

//房号查询得到的10个transaction信息
$card_id = $_POST["card_id"];

$transaction_id = explode(",", $_POST["transaction_id"]);
$stuff_id = explode(",", $_POST["stuff_id"]);
$payment_id = explode(",", $_POST["payment_id"]);
$reserve_time = explode(",", $_POST["reserve_time"]);
$reserve_days = explode(",", $_POST["reserve_days"]);
$reserveStore_time = explode(",", $_POST["reserveStore_time"]);
$checkIn_time = explode(",", $_POST["checkIn_time"]);
$leave_time = explode(",", $_POST["leave_time"]);
$transaction_status = explode(",", $_POST["transaction_status"]);
$remark = explode(",", $_POST["remark"]);

//房号查询得到的transaction_id的room信息
$room_id = explode(",", $_POST["room_id"]);
$roomType_id = explode(",", $_POST["roomType_id"]);
$room_status = explode(",", $_POST["room_status"]);

$count_transaction = count($transaction_id);
echo "
        <table>
            <tr>
                <th>顾客证件号</th>
                <th>订单号</th>
                <th>操作员</th>
                <th>付款号</th>
                
                <th>预定房号</th>
                <th>预定房型</th>
                <th>房间状态</th>
                
                <th>预定时间</th>
                <th>预住天数</th>
                <th>订单生成时间</th>
                <th>Check In 时间</th>
                <th>Check Out 时间</th>
                <th>订单状态</th>
                <th>备注</th>
            </tr>";

for ($i = 0; $i < $count_transaction; $i++) {
    echo "
                <tr>
                    <th>" . $card_id . "</th>
                    <th>" . $transaction_id[$i] . "</th>
                    <th>" . $stuff_id[$i] . "</th>
                    <th>" . $payment_id[$i] . "</th>
                    
                    <th>" . $room_id[$i] . "</th>

                    <th>" . $roomType[$roomType_id[$i]] . "</th>
                    <th>" . $room_status[$i] . "</th>
                    
                    <th>" . $reserve_time[$i] . "</th>
                    <th>" . $reserve_days[$i] . "</th>
                    <th>" . $reserveStore_time[$i] . "</th>
                    <th>" . $checkIn_time[$i] . "</th>
                    <th>" . $leave_time[$i] . "</th>
                    <th>" . $transaction_status[$i] . "</th>
                    <th>" . $remark[$i] . "</th>
        ";
//    var_dump($checkIn_time[$i]);
    if ($checkIn_time[$i] == '') {
        echo
            "
            <th>
                <form action='op_order.php' method='post'>
                    <input type='hidden' name='card_id' value='".$card_id."'>
                    <input type='hidden' name='room_id' value='".$room_id[$i] ."'>
                    <input type='hidden' name='transaction_id' value='" . $transaction_id[$i] . "'>
                    <input type='hidden' name='op' value='2'>
                    <input type='submit' value='Check In'>
                </form>
            </th>";
    }
    echo "</tr>";
}
echo "</table>";


?>
</html>